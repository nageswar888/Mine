// Indicator Engine - Mathematical indicator calculations only
// NEVER generates signals, only produces numerical values

import { Candle, IndicatorValues } from '../types';

export class IndicatorEngine {
  // Exponential Moving Average
  static ema(data: number[], period: number): number[] {
    const result: number[] = [];
    const multiplier = 2 / (period + 1);

    if (data.length === 0) return result;

    // Start with SMA for first value
    let sum = 0;
    for (let i = 0; i < Math.min(period, data.length); i++) {
      sum += data[i];
    }
    result[0] = sum / Math.min(period, data.length);

    // Calculate EMA for remaining values
    for (let i = 1; i < data.length; i++) {
      if (i < period) {
        result[i] = (data[i] + result[i - 1] * i) / (i + 1);
      } else {
        result[i] = (data[i] - result[i - 1]) * multiplier + result[i - 1];
      }
    }

    return result;
  }

  // Simple Moving Average
  static sma(data: number[], period: number): number[] {
    const result: number[] = [];
    for (let i = 0; i < data.length; i++) {
      if (i < period - 1) {
        result.push(NaN);
      } else {
        const sum = data.slice(i - period + 1, i + 1).reduce((a, b) => a + b, 0);
        result.push(sum / period);
      }
    }
    return result;
  }

  // Relative Strength Index
  static rsi(closes: number[], period: number = 14): number[] {
    const result: number[] = [];

    if (closes.length < period + 1) {
      return closes.map(() => 50);
    }

    let avgGain = 0;
    let avgLoss = 0;

    // Calculate initial averages
    for (let i = 1; i <= period; i++) {
      const change = closes[i] - closes[i - 1];
      if (change > 0) avgGain += change;
      else avgLoss += Math.abs(change);
    }

    avgGain /= period;
    avgLoss /= period;

    // First RSI value
    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    result.push(100 - 100 / (1 + rs));

    // Calculate subsequent values using smoothed method
    for (let i = period + 1; i < closes.length; i++) {
      const change = closes[i] - closes[i - 1];
      const gain = change > 0 ? change : 0;
      const loss = change < 0 ? Math.abs(change) : 0;

      avgGain = (avgGain * (period - 1) + gain) / period;
      avgLoss = (avgLoss * (period - 1) + loss) / period;

      const rsValue = avgLoss === 0 ? 100 : avgGain / avgLoss;
      result.push(100 - 100 / (1 + rsValue));
    }

    // Pad beginning with 50
    while (result.length < closes.length - period) {
      result.unshift(50);
    }

    return result;
  }

  // MACD
  static macd(closes: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9): {
    macd: number[];
    signal: number[];
    histogram: number[];
  } {
    const emaFast = this.ema(closes, fastPeriod);
    const emaSlow = this.ema(closes, slowPeriod);

    const macdLine: number[] = [];
    for (let i = 0; i < closes.length; i++) {
      macdLine.push(emaFast[i] - emaSlow[i]);
    }

    const signalLine = this.ema(macdLine.slice(slowPeriod - 1), signalPeriod);

    // Align arrays
    const paddedSignal: number[] = [];
    for (let i = 0; i < slowPeriod - 1 + signalPeriod - 1; i++) {
      paddedSignal.push(0);
    }
    paddedSignal.push(...signalLine);

    const histogram: number[] = [];
    for (let i = 0; i < macdLine.length; i++) {
      histogram.push(macdLine[i] - (paddedSignal[i] || 0));
    }

    return { macd: macdLine, signal: paddedSignal, histogram };
  }

  // Average True Range
  static atr(candles: Candle[], period: number = 14): number[] {
    const trueRanges: number[] = [];

    for (let i = 0; i < candles.length; i++) {
      if (i === 0) {
        trueRanges.push(candles[i].high - candles[i].low);
      } else {
        const tr = Math.max(
          candles[i].high - candles[i].low,
          Math.abs(candles[i].high - candles[i - 1].close),
          Math.abs(candles[i].low - candles[i - 1].close)
        );
        trueRanges.push(tr);
      }
    }

    // Calculate ATR using EMA of true ranges
    return this.ema(trueRanges, period);
  }

  // Average Directional Index
  static adx(candles: Candle[], period: number = 14): number[] {
    const plusDM: number[] = [0];
    const minusDM: number[] = [0];
    const trueRange: number[] = [candles[0].high - candles[0].low];

    for (let i = 1; i < candles.length; i++) {
      const upMove = candles[i].high - candles[i - 1].high;
      const downMove = candles[i - 1].low - candles[i].low;
      plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
      minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
      trueRange.push(Math.max(
        candles[i].high - candles[i].low,
        Math.abs(candles[i].high - candles[i - 1].close),
        Math.abs(candles[i].low - candles[i - 1].close)
      ));
    }

    const atr: number[] = [];
    const smoothedPlusDM: number[] = [];
    const smoothedMinusDM: number[] = [];
    const dx: number[] = [];
    const adx: number[] = [];

    if (candles.length === 0) return adx;

    let trSum = 0;
    let plusDMSum = 0;
    let minusDMSum = 0;

    for (let i = 1; i <= period && i < trueRange.length; i++) {
      trSum += trueRange[i];
      plusDMSum += plusDM[i];
      minusDMSum += minusDM[i];
    }

    atr[period] = trSum / period;
    smoothedPlusDM[period] = plusDMSum / period;
    smoothedMinusDM[period] = minusDMSum / period;

    for (let i = period + 1; i < candles.length; i++) {
      atr[i] = ((atr[i - 1] * (period - 1)) + trueRange[i]) / period;
      smoothedPlusDM[i] = ((smoothedPlusDM[i - 1] * (period - 1)) + plusDM[i]) / period;
      smoothedMinusDM[i] = ((smoothedMinusDM[i - 1] * (period - 1)) + minusDM[i]) / period;
    }

    for (let i = 0; i < candles.length; i++) {
      if (i < period) {
        adx.push(25);
        continue;
      }

      const currentAtr = atr[i] || atr[period] || 0;
      const currentPlus = smoothedPlusDM[i] || 0;
      const currentMinus = smoothedMinusDM[i] || 0;
      const plusDI = currentAtr !== 0 ? (currentPlus / currentAtr) * 100 : 0;
      const minusDI = currentAtr !== 0 ? (currentMinus / currentAtr) * 100 : 0;
      const dxValue = plusDI + minusDI !== 0 ? (Math.abs(plusDI - minusDI) / (plusDI + minusDI)) * 100 : 0;
      dx.push(dxValue);

      if (i === period) {
        const dxSum = dx.slice(period - period + 1, period + 1).reduce((sum, val) => sum + val, 0);
        adx[i] = dxSum / period;
      } else {
        adx[i] = ((adx[i - 1] * (period - 1)) + dxValue) / period;
      }
    }

    return adx.map((value) => Math.round(value * 10) / 10);
  }

  // Bollinger Bands
  static bollingerBands(closes: number[], period: number = 20, stdDev: number = 2): {
    upper: number[];
    middle: number[];
    lower: number[];
    percentB: number[];
  } {
    const middle = this.sma(closes, period);
    const upper: number[] = [];
    const lower: number[] = [];
    const percentB: number[] = [];

    for (let i = 0; i < closes.length; i++) {
      if (i < period - 1) {
        upper.push(NaN);
        lower.push(NaN);
        percentB.push(0.5);
      } else {
        const slice = closes.slice(i - period + 1, i + 1);
        const mean = middle[i];
        const variance = slice.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / period;
        const std = Math.sqrt(variance);

        upper.push(mean + stdDev * std);
        lower.push(mean - stdDev * std);

        const bandwidth = upper[i] - lower[i];
        percentB.push(bandwidth !== 0 ? (closes[i] - lower[i]) / bandwidth : 0.5);
      }
    }

    return { upper, middle, lower, percentB };
  }

  // Stochastic Oscillator
  static stochastic(candles: Candle[], kPeriod: number = 14, dPeriod: number = 3): {
    k: number[];
    d: number[];
  } {
    const kValues: number[] = [];

    for (let i = 0; i < candles.length; i++) {
      if (i < kPeriod - 1) {
        kValues.push(50);
      } else {
        const slice = candles.slice(i - kPeriod + 1, i + 1);
        const highestHigh = Math.max(...slice.map(c => c.high));
        const lowestLow = Math.min(...slice.map(c => c.low));
        const range = highestHigh - lowestLow;

        kValues.push(range !== 0 ? ((candles[i].close - lowestLow) / range) * 100 : 50);
      }
    }

    const dValues = this.sma(kValues, dPeriod);

    return { k: kValues, d: dValues.map(v => (isNaN(v) ? 50 : v)) };
  }

  // On-Balance Volume
  static obv(candles: Candle[]): number[] {
    const result: number[] = [0];

    for (let i = 1; i < candles.length; i++) {
      const prevOBV = result[i - 1];
      if (candles[i].close > candles[i - 1].close) {
        result.push(prevOBV + candles[i].volume);
      } else if (candles[i].close < candles[i - 1].close) {
        result.push(prevOBV - candles[i].volume);
      } else {
        result.push(prevOBV);
      }
    }

    return result;
  }

  // VWAP (Volume Weighted Average Price)
  static vwap(candles: Candle[]): number[] {
    const result: number[] = [];
    let cumVolPrice = 0;
    let cumVol = 0;

    for (const candle of candles) {
      const typicalPrice = (candle.high + candle.low + candle.close) / 3;
      cumVolPrice += typicalPrice * candle.volume;
      cumVol += candle.volume;
      result.push(cumVol !== 0 ? cumVolPrice / cumVol : typicalPrice);
    }

    return result;
  }

  // Calculate all indicators
  static calculateAll(candles: Candle[]): IndicatorValues {
    if (candles.length < 200) {
      // Not enough data, return defaults
      return this.getDefaultValues();
    }

    const closes = candles.map(c => c.close);

    const ema20Array = this.ema(closes, 20);
    const ema50Array = this.ema(closes, 50);
    const ema200Array = this.ema(closes, 200);
    const rsiArray = this.rsi(closes, 14);
    const macdResult = this.macd(closes);
    const atrArray = this.atr(candles);
    const adxArray = this.adx(candles);
    const bbResult = this.bollingerBands(closes);
    const stochResult = this.stochastic(candles);
    const obvArray = this.obv(candles);
    const vwapArray = this.vwap(candles);

    const lastIdx = candles.length - 1;

    return {
      ema20: ema20Array[lastIdx] || closes[lastIdx],
      ema50: ema50Array[lastIdx] || closes[lastIdx],
      ema200: ema200Array[lastIdx] || closes[lastIdx],
      rsi: rsiArray[rsiArray.length - 1] || 50,
      macd: {
        macd: macdResult.macd[lastIdx] || 0,
        signal: macdResult.signal[lastIdx] || 0,
        histogram: macdResult.histogram[lastIdx] || 0
      },
      atr: atrArray[lastIdx] || 0,
      adx: adxArray[lastIdx] || 25,
      bollingerBands: {
        upper: bbResult.upper[lastIdx] || closes[lastIdx],
        middle: bbResult.middle[lastIdx] || closes[lastIdx],
        lower: bbResult.lower[lastIdx] || closes[lastIdx],
        percentB: bbResult.percentB[lastIdx] || 0.5
      },
      stochastic: {
        k: stochResult.k[lastIdx] || 50,
        d: stochResult.d[lastIdx] || 50
      },
      obv: obvArray[lastIdx] || 0,
      vwap: vwapArray[lastIdx] || closes[lastIdx]
    };
  }

  private static getDefaultValues(): IndicatorValues {
    return {
      ema20: 0,
      ema50: 0,
      ema200: 0,
      rsi: 50,
      macd: { macd: 0, signal: 0, histogram: 0 },
      atr: 0,
      adx: 25,
      bollingerBands: { upper: 0, middle: 0, lower: 0, percentB: 0.5 },
      stochastic: { k: 50, d: 50 },
      obv: 0,
      vwap: 0
    };
  }
}
