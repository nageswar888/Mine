// Liquidity Engine - Detects liquidity events (sweeps, fake breakouts, stop hunts)
// NEVER generates CALL/PUT signals

import { MarketSnapshot, LiquidityAnalysis, LiquidityEvent } from '../../types';

export class LiquidityEngine {
  private static readonly SWEEP_THRESHOLD = 0.001; // 0.1% beyond level
  private static readonly LOOKBACK = 20;

  static analyze(snapshot: MarketSnapshot): LiquidityAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const recent = candles.slice(-this.LOOKBACK);
    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];

    // Find key levels for liquidity
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));

    // Detect liquidity sweep
    const sweepResult = this.detectSweep(last, prev, recentHigh, recentLow);

    // Detect fake breakout
    const fakeout = this.detectFakeout(last, candles);

    // Detect stop hunt heuristic
    const stopHunt = this.detectStopHunt(last, candles);

    // Determine event type
    const event = this.determineEvent(sweepResult, fakeout, stopHunt);

    // Calculate score
    const score = this.calculateScore(event, last, recentHigh, recentLow);

    const pass = event === 'none' || event === 'sweep';

    const reasons: string[] = [];
    if (event === 'sweep') {
      reasons.push('Liquidity sweep detected - stops likely cleared');
    } else if (event === 'fake_breakout') {
      reasons.push('⚠ Fake breakout - level held, avoid trading');
    } else if (event === 'stop_hunt') {
      reasons.push('⚠ Potential stop hunt - volatility spike');
    } else {
      reasons.push('No significant liquidity event');
    }

    return {
      score,
      pass,
      reasons,
      event,
      sweptLevel: sweepResult.level,
      fakeoutDetected: fakeout.detected,
      details: {
        recentHigh,
        recentLow,
        volume: last.volume,
        volumeAvg: this.calculateAvgVolume(recent),
        sweepRatio: sweepResult.ratio
      }
    };
  }

  private static detectSweep(
    last: Candle,
    prev: Candle,
    recentHigh: number,
    recentLow: number
  ): { detected: boolean; level?: number; ratio: number } {
    const threshold = recentHigh * this.SWEEP_THRESHOLD;

    // Check for bullish sweep (sweep below low then close up)
    if (last.low < recentLow - threshold && last.close > prev.low) {
      return {
        detected: true,
        level: recentLow,
        ratio: (last.close - last.low) / (last.high - last.low)
      };
    }

    // Check for bearish sweep (sweep above high then close down)
    if (last.high > recentHigh + threshold && last.close < prev.high) {
      return {
        detected: true,
        level: recentHigh,
        ratio: (last.high - last.close) / (last.high - last.low)
      };
    }

    return { detected: false, ratio: 0 };
  }

  private static detectFakeout(last: Candle, candles: Candle[]): { detected: boolean; direction?: 'up' | 'down' } {
    const recent = candles.slice(-15);
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));
    const range = recentHigh - recentLow;

    if (range < 0.0001) return { detected: false };

    // Fake breakout up: broke high but closed back inside range
    if (last.high > recentHigh && last.close < recentHigh - range * 0.1) {
      return { detected: true, direction: 'up' };
    }

    // Fake breakout down: broke low but closed back inside range
    if (last.low < recentLow && last.close > recentLow + range * 0.1) {
      return { detected: true, direction: 'down' };
    }

    return { detected: false };
  }

  private static detectStopHunt(last: Candle, candles: Candle[]): boolean {
    const prev = candles[candles.length - 2];
    const third = candles[candles.length - 3];

    // Stop hunt: rapid price move with quick reversal
    const body = Math.abs(last.close - last.open);
    const prevBody = Math.abs(prev.close - prev.open);
    const range = last.high - last.low;

    // Long wick relative to body indicates rejection
    const upperWick = last.high - Math.max(last.open, last.close);
    const lowerWick = Math.min(last.open, last.close) - last.low;
    const maxWick = Math.max(upperWick, lowerWick);

    // Conditions for stop hunt heuristic
    const rapidMove = body > prevBody * 1.5;
    const longWick = maxWick > body * 2;
    const highVolume = last.volume > this.calculateAvgVolume(candles.slice(-10)) * 1.5;

    return longWick && highVolume && rapidMove;
  }

  private static determineEvent(
    sweepResult: { detected: boolean },
    fakeout: { detected: boolean },
    stopHunt: boolean
  ): LiquidityEvent {
    if (fakeout.detected) return 'fake_breakout';
    if (stopHunt) return 'stop_hunt';
    if (sweepResult.detected) return 'sweep';
    return 'none';
  }

  private static calculateScore(
    event: LiquidityEvent,
    last: Candle,
    recentHigh: number,
    recentLow: number
  ): number {
    let score = 0;

    if (event === 'sweep') {
      // Sweeps can be positive - liquidity cleared, continuation possible
      const closePosition = (last.close - recentLow) / (recentHigh - recentLow);
      score = closePosition > 0.5 ? 15 : -15;
    } else if (event === 'fake_breakout') {
      // Fake breakouts are negative - avoid
      score = -25;
    } else if (event === 'stop_hunt') {
      // Stop hunts are warnings
      score = -20;
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static calculateAvgVolume(candles: Candle[]): number {
    if (candles.length === 0) return 0;
    return candles.reduce((sum, c) => sum + c.volume, 0) / candles.length;
  }

  private static insufficientData(): LiquidityAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for liquidity analysis'],
      event: 'none',
      fakeoutDetected: false,
      details: {}
    };
  }
}

interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
