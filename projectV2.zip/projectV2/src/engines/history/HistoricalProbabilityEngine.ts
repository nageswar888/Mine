import { HistoricalMemoryEngine } from './HistoricalMemoryEngine';
import { HistoricalProbabilityAnalysis, EngineResult } from '../../types';

export class HistoricalProbabilityEngine {
  static analyze(
    engineResults: Record<string, EngineResult>,
    memory: HistoricalMemoryEngine
  ): HistoricalProbabilityAnalysis {
    const { similarTrades, similarityScore } = memory.findSimilarSetups(engineResults);
    const sampleSize = similarTrades.length;
    const winRate = memory.getWinRate();
    const lossRate = memory.getLossRate();
    const averageConfidence = similarTrades.length > 0
      ? Math.round(similarTrades.reduce((sum, trade) => sum + trade.confidence, 0) / similarTrades.length)
      : 50;
    const probability = sampleSize > 0
      ? Math.round((winRate * 0.6 + averageConfidence * 0.4) / 100 * 100)
      : 50;
    const reliability = memory.getReliability(sampleSize);

    const pass = probability >= 50 && reliability >= 40;
    const reasons: string[] = [];

    if (similarityScore > 60) {
      reasons.push('Strong match against historical setups');
    }
    if (sampleSize < 5) {
      reasons.push('Limited historical sample size');
    }
    if (winRate >= 60) {
      reasons.push('Historical win bias detected');
    }
    if (lossRate >= 60) {
      reasons.push('Historical loss bias detected');
    }

    return {
      score: probability - 50,
      pass,
      reasons,
      probability,
      sampleSize,
      reliability,
      details: {
        similarityScore,
        winRate,
        lossRate,
        averageConfidence
      }
    };
  }
}
