// Confluence Engine - Measures agreement between all analysis engines
// NEVER generates CALL/PUT signals
// ACCURACY FOCUS: Require strong agreement, reject mixed signals

import { MarketSnapshot, ConfluenceResult, EngineResult } from '../../types';

export class ConfluenceEngine {
  static analyze(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>
  ): ConfluenceResult {
    const engineCount = Object.keys(engineResults).length;

    if (engineCount < 5) {
      return this.insufficientData();
    }

    // Categorize engines by importance
    const criticalEngines = ['trend', 'momentum', 'structure', 'regime'];
    const importantEngines = ['volatility', 'supportResistance', 'liquidity', 'pullback'];
    const supportingEngines = ['candlestick', 'session', 'trendAge', 'trendSlope', 'stability', 'breakout', 'retest'];

    // Count directional bias with weights
    let bullishScore = 0;
    let bearishScore = 0;
    let neutralScore = 0;

    let bullishEngines = 0;
    let bearishEngines = 0;
    let neutralEngines = 0;

    const weights: Record<string, number> = {
      trend: 4,
      momentum: 4,
      structure: 3,
      regime: 3,
      volatility: 2,
      supportResistance: 2,
      liquidity: 2,
      pullback: 2,
      candlestick: 1,
      session: 1,
      trendAge: 1,
      trendSlope: 1,
      stability: 1,
      breakout: 1.5,
      retest: 1
    };

    const significantThreshold = 15; // Score must be ±15 to count as directional

    for (const [name, result] of Object.entries(engineResults)) {
      const weight = weights[name] || 1;
      const score = result.score;

      if (score > significantThreshold) {
        bullishEngines++;
        bullishScore += Math.abs(score) * weight * 0.1;
      } else if (score < -significantThreshold) {
        bearishEngines++;
        bearishScore += Math.abs(score) * weight * 0.1;
      } else {
        neutralEngines++;
        neutralScore += weight;
      }
    }

    // Calculate weighted agreement
    const totalWeighted = bullishScore + bearishScore + neutralScore;
    const agreement = this.calculateAgreement(
      bullishScore,
      bearishScore,
      neutralScore,
      totalWeighted,
      criticalEngines,
      engineResults
    );

    // Find key alignments (multiple engines pointing same direction)
    const keyAlignments = this.findKeyAlignments(engineResults, criticalEngines);

    // Find contradictions (critical disagreement)
    const contradictions = this.findContradictions(engineResults, criticalEngines);

    return {
      agreement,
      bullishEngines,
      bearishEngines,
      neutralEngines,
      keyAlignments,
      contradictions
    };
  }

  private static calculateAgreement(
    bullishScore: number,
    bearishScore: number,
    neutralScore: number,
    total: number,
    criticalEngines: string[],
    engineResults: Record<string, EngineResult>
  ): number {
    if (total === 0) return 0;

    // Base agreement from weighted distribution
    const maxDirection = Math.max(bullishScore, bearishScore);
    const baseAgreement = (maxDirection / total) * 70;

    // Check if critical engines agree
    const criticalAgreement = this.checkCriticalAgreement(criticalEngines, engineResults);

    // Final agreement: base + critical bonus
    const finalAgreement = baseAgreement + (criticalAgreement ? 25 : 0);

    // Penalty if neutral dominates (no clear direction)
    if (neutralScore > total * 0.4) {
      return Math.round(finalAgreement * 0.7);
    }

    return Math.round(Math.min(100, finalAgreement));
  }

  private static checkCriticalAgreement(
    criticalEngines: string[],
    engineResults: Record<string, EngineResult>
  ): boolean {
    // At least 3 of 4 critical engines must agree on direction
    let bullishCount = 0;
    let bearishCount = 0;

    for (const engine of criticalEngines) {
      const result = engineResults[engine];
      if (!result) continue;

      if (result.score > 15) bullishCount++;
      else if (result.score < -15) bearishCount++;
    }

    return bullishCount >= 3 || bearishCount >= 3;
  }

  private static findKeyAlignments(
    engineResults: Record<string, EngineResult>,
    criticalEngines: string[]
  ): string[] {
    const alignments: string[] = [];

    const trend = engineResults['trend'];
    const momentum = engineResults['momentum'];
    const structure = engineResults['structure'];
    const regime = engineResults['regime'];

    // Trend + Momentum alignment (most important)
    if (trend && momentum) {
      const bothBullish = trend.score > 15 && momentum.score > 15;
      const bothBearish = trend.score < -15 && momentum.score < -15;
      if (bothBullish) alignments.push('Trend + Momentum aligned BULLISH');
      if (bothBearish) alignments.push('Trend + Momentum aligned BEARISH');
    }

    // Structure + Regime alignment
    if (structure && regime) {
      const bothAlign = Math.sign(structure.score) === Math.sign(regime.score) && Math.abs(structure.score) > 10;
      if (bothAlign && regime.details?.regime === 'trending') {
        alignments.push('Structure supports trending regime');
      } else if (regime.details?.regime === 'sideways') {
        alignments.push('⚠ Sideways regime - avoid breakout entries');
      }
    }

    // Pullback confirmation
    const pullback = engineResults['pullback'];
    if (pullback && pullback.details?.inPullback && pullback.details?.healthy) {
      alignments.push('Healthy pullback for entry');
    }

    // Breakout confirmation
    const breakout = engineResults['breakout'];
    if (breakout && breakout.details?.confirmed) {
      alignments.push(`Breakout confirmed (${breakout.details?.direction})`);
    }

    return alignments.slice(0, 4);
  }

  private static findContradictions(
    engineResults: Record<string, EngineResult>,
    criticalEngines: string[]
  ): string[] {
    const contradictions: string[] = [];

    const trend = engineResults['trend'];
    const momentum = engineResults['momentum'];
    const structure = engineResults['structure'];
    const regime = engineResults['regime'];

    // Trend vs Momentum contradiction (critical)
    if (trend && momentum) {
      if (trend.score > 20 && momentum.score < -20) {
        contradictions.push('Trend bullish but momentum bearish');
      }
      if (trend.score < -20 && momentum.score > 20) {
        contradictions.push('Trend bearish but momentum bullish');
      }
    }

    // Structure vs regime contradiction
    if (structure && regime) {
      if (structure.score > 20 && regime.details?.regime === 'sideways') {
        contradictions.push('Bullish structure in sideways regime');
      }
      if (structure.score < -20 && regime.details?.regime === 'sideways') {
        contradictions.push('Bearish structure in sideways regime');
      }
    }

    // Divergence warning
    if (momentum?.details?.divergence) {
      contradictions.push(`Divergence detected (${momentum.details?.divergenceType})`);
    }

    // Volatility warning
    const volatility = engineResults['volatility'];
    if (volatility && volatility.details?.state === 'extreme') {
      contradictions.push('Extreme volatility - unpredictable moves');
    }

    return contradictions;
  }

  static calculateConfluenceScore(confluence: ConfluenceResult): number {
    let score = 0;

    // Agreement contribution
    score += (confluence.agreement - 50) * 0.6;

    // Direction contribution
    const directionBias = confluence.bullishEngines - confluence.bearishEngines;
    const total = confluence.bullishEngines + confluence.bearishEngines + confluence.neutralEngines;
    const directionScore = total > 0 ? (directionBias / total) * 30 : 0;
    score += directionScore;

    // Key alignments bonus
    score += confluence.keyAlignments.length * 5;

    // Contradictions penalty (heavy for accuracy)
    score -= confluence.contradictions.length * 20;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): ConfluenceResult {
    return {
      agreement: 0,
      bullishEngines: 0,
      bearishEngines: 0,
      neutralEngines: 0,
      keyAlignments: [],
      contradictions: ['Insufficient engine data for confluence analysis']
    };
  }
}
