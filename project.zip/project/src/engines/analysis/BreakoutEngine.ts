// Breakout Engine - Confirms valid breakouts
// NEVER generates CALL/PUT signals

import { MarketSnapshot, BreakoutAnalysis } from '../../types';

export class BreakoutEngine {
  private static readonly LOOKBACK = 20;
  private static readonly BREAKOUT_THRESHOLD = 0.002; // 0.2% beyond level
  private static readonly CONFIRMATION_CANDLES = 2;

  static analyze(snapshot: MarketSnapshot): BreakoutAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const recent = candles.slice(-this.LOOKBACK);
    const closes = candles.map(c => c.close);

    // Find consolidation range
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));
    const range = recentHigh - recentLow;

    // Check for breakout
    const breakout = this.detectBreakout(candles, recentHigh, recentLow, range);

    // Check for retest
    const retest = this.detectRetest(candles, breakout, recentHigh, recentLow);

    // Check if breakout is confirmed
    const confirmed = this.confirmBreakout(candles, breakout, range);

    // Calculate score
    const score = this.calculateScore(breakout, confirmed, retest);

    const pass = breakout.direction !== 'none' && confirmed;

    const reasons: string[] = [];
    if (breakout.direction === 'up') {
      if (confirmed) {
        reasons.push('Confirmed bullish breakout');
      } else {
        reasons.push('Potential bullish breakout - awaiting confirmation');
      }
    } else if (breakout.direction === 'down') {
      if (confirmed) {
        reasons.push('Confirmed bearish breakout');
      } else {
        reasons.push('Potential bearish breakout - awaiting confirmation');
      }
    } else {
      reasons.push('No breakout detected');
    }

    if (retest) {
      reasons.push('Retest of breakout level successful');
    }

    if (breakout.fakeout) {
      reasons.push('⚠ Potential fake breakout - be cautious');
    }

    return {
      score,
      pass,
      reasons,
      confirmed,
      direction: breakout.direction,
      retest,
      details: {
        breakoutLevel: breakout.level,
        breakoutStrength: breakout.strength,
        volume: breakout.volume,
        range: range
      }
    };
  }

  private static detectBreakout(
    candles: Candle[],
    recentHigh: number,
    recentLow: number,
    range: number
  ): {
    direction: 'up' | 'down' | 'none';
    level: number;
    strength: number;
    fakeout: boolean;
    volume: number;
  } {
    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];
    const threshold = range * this.BREAKOUT_THRESHOLD / range || this.BREAKOUT_THRESHOLD;

    // Check for upside breakout
    if (last.close > recentHigh + threshold) {
      const strength = this.calculateBreakoutStrength(candles, 'up', recentHigh);
      const fakeout = this.checkFakeout(candles, recentHigh, 'up');

      return {
        direction: 'up',
        level: recentHigh,
        strength,
        fakeout,
        volume: last.volume
      };
    }

    // Check for downside breakout
    if (last.close < recentLow - threshold) {
      const strength = this.calculateBreakoutStrength(candles, 'down', recentLow);
      const fakeout = this.checkFakeout(candles, recentLow, 'down');

      return {
        direction: 'down',
        level: recentLow,
        strength,
        fakeout,
        volume: last.volume
      };
    }

    return { direction: 'none', level: 0, strength: 0, fakeout: false, volume: 0 };
  }

  private static calculateBreakoutStrength(
    candles: Candle[],
    direction: 'up' | 'down',
    level: number
  ): number {
    const last = candles[candles.length - 1];
    const avgVolume = candles.slice(-10).reduce((s, c) => s + c.volume, 0) / 10;

    // Body size relative to average
    const avgBody = candles.slice(-10).reduce((s, c) => s + Math.abs(c.close - c.open), 0) / 10;
    const bodySize = Math.abs(last.close - last.open);
    const bodyScore = Math.min(40, (bodySize / avgBody) * 20);

    // Volume score
    const volumeScore = Math.min(30, (last.volume / avgVolume) * 15);

    // Distance from level
    const distance = direction === 'up'
      ? ((last.close - level) / level) * 100
      : ((level - last.close) / last.close) * 100;
    const distanceScore = Math.min(30, distance * 15);

    return Math.round(bodyScore + volumeScore + distanceScore);
  }

  private static checkFakeout(
    candles: Candle[],
    level: number,
    direction: 'up' | 'down'
  ): boolean {
    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];

    // Fakeout if wick extends beyond level but closes back
    if (direction === 'up') {
      return last.high > level && last.close < level;
    } else {
      return last.low < level && last.close > level;
    }
  }

  private static detectRetest(
    candles: Candle[],
    breakout: { direction: 'up' | 'down' | 'none'; level: number; fakeout: boolean },
    recentHigh: number,
    recentLow: number
  ): boolean {
    if (breakout.direction === 'none' || breakout.fakeout) return false;

    const last = candles[candles.length - 1];
    const level = breakout.level;

    // Retest: price came back near the breakout level
    const nearLevel = Math.abs(last.close - level) / level < 0.01;

    // But didn't cross back
    if (breakout.direction === 'up') {
      return nearLevel && last.low >= level * 0.995;
    } else {
      return nearLevel && last.high <= level * 1.005;
    }
  }

  private static confirmBreakout(
    candles: Candle[],
    breakout: { direction: 'up' | 'down' | 'none'; fakeout: boolean },
    range: number
  ): boolean {
    if (breakout.direction === 'none' || breakout.fakeout) return false;

    const last = candles[candles.length - 1];
    const body = Math.abs(last.close - last.open);
    const avgBody = candles.slice(-10).reduce((s, c) => s + Math.abs(c.close - c.open), 0) / 10;

    // Confirmation criteria:
    // 1. Good body size (at least average)
    // 2. Close beyond level
    // 3. Not a fakeout

    return body >= avgBody * 0.8 && !breakout.fakeout;
  }

  private static calculateScore(
    breakout: { direction: 'up' | 'down' | 'none'; strength: number; fakeout: boolean },
    confirmed: boolean,
    retest: boolean
  ): number {
    let score = 0;

    if (breakout.direction === 'none') return 0;

    if (breakout.fakeout) return -30;

    // Base breakout score
    score = breakout.strength;

    // Confirmation bonus
    if (confirmed) score += 15;

    // Retest bonus
    if (retest) score += 10;

    // Direction contribution
    if (breakout.direction === 'up') {
      score = Math.max(0, score);
    } else {
      score = -Math.max(0, score);
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): BreakoutAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for breakout analysis'],
      confirmed: false,
      direction: 'none',
      retest: false,
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  close: number;
  open: number;
  volume: number;
}
