// Volatility Engine - Determines volatility state (healthy, low, extreme)
// NEVER generates CALL/PUT signals

import { MarketSnapshot, VolatilityAnalysis, VolatilityState } from '../../types';
import { IndicatorEngine } from '../indicators';

export class VolatilityEngine {
  private static readonly LOW_VOL_THRESHOLD = 20;
  private static readonly EXTREME_VOL_THRESHOLD = 80;

  static analyze(snapshot: MarketSnapshot): VolatilityAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const atr = IndicatorEngine.atr(candles, 14);
    const lastIdx = candles.length - 1;
    const currentAtr = atr[lastIdx] || 0;

    // Calculate ATR percentile (relative to recent history)
    const atrHistory = atr.slice(-50);
    const atrPercentile = this.calculatePercentile(currentAtr, atrHistory);

    // Calculate expansion rate
    const expansionRate = this.calculateExpansionRate(atr, lastIdx);

    // Determine volatility state
    const state = this.determineState(atrPercentile, expansionRate);

    // Calculate score
    const score = this.calculateScore(state, atrPercentile, expansionRate);

    const pass = state === 'healthy' || (state === 'low' && atrPercentile > 30);

    const reasons: string[] = [];
    if (state === 'healthy') {
      reasons.push('Healthy volatility - good trading conditions');
    } else if (state === 'low') {
      reasons.push('⚠ Low volatility - potential breakout incoming');
    } else if (state === 'extreme') {
      reasons.push('⚠ Extreme volatility - high risk conditions');
    }

    if (expansionRate > 20) {
      reasons.push('Volatility expanding rapidly');
    } else if (expansionRate < -20) {
      reasons.push('Volatility contracting');
    }

    return {
      score,
      pass,
      reasons,
      state,
      atrPercentile,
      expansionRate,
      details: {
        atr: currentAtr,
        atrAvg: this.calculateAverage(atrHistory),
        atrMax: Math.max(...atrHistory),
        atrMin: Math.min(...atrHistory)
      }
    };
  }

  private static calculatePercentile(value: number, history: number[]): number {
    const below = history.filter(v => v < value).length;
    return Math.round((below / history.length) * 100);
  }

  private static calculateExpansionRate(atr: number[], idx: number): number {
    if (idx < 10) return 0;

    const current = atr[idx] || 0;
    const prev = atr[idx - 10] || current;
    const avg = (current + prev) / 2;

    return avg !== 0 ? ((current - prev) / avg) * 100 : 0;
  }

  private static determineState(percentile: number, expansionRate: number): VolatilityState {
    // Extreme volatility if rapidly expanding or percentile is very high
    if (percentile > this.EXTREME_VOL_THRESHOLD || expansionRate > 50) {
      return 'extreme';
    }

    // Low volatility if percentile is low and not expanding
    if (percentile < this.LOW_VOL_THRESHOLD && expansionRate < 20) {
      return 'low';
    }

    return 'healthy';
  }

  private static calculateScore(
    state: VolatilityState,
    percentile: number,
    expansionRate: number
  ): number {
    let score = 0;

    // Healthy volatility is ideal
    if (state === 'healthy') {
      // Score based on distance from extremes
      const distanceFromExtremes = Math.min(percentile, 100 - percentile);
      score = distanceFromExtremes;
    } else if (state === 'low') {
      // Low volatility - can be good for breakout setups, but not ideal for trend following
      score = -20;
    } else if (state === 'extreme') {
      // Extreme volatility - high risk
      score = -40;
    }

    // Expansion rate modifier
    if (expansionRate > 30) {
      score -= 10; // Rapid expansion is risky
    } else if (expansionRate < -30) {
      score += 5; // Contraction can precede moves
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static calculateAverage(arr: number[]): number {
    const valid = arr.filter(v => isFinite(v) && !isNaN(v));
    if (valid.length === 0) return 0;
    return valid.reduce((sum, v) => sum + v, 0) / valid.length;
  }

  private static insufficientData(): VolatilityAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for volatility analysis'],
      state: 'healthy',
      atrPercentile: 50,
      expansionRate: 0,
      details: {}
    };
  }
}
