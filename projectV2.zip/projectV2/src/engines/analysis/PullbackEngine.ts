// Pullback Engine - Detects healthy retracements
// NEVER generates CALL/PUT signals

import { MarketSnapshot, PullbackAnalysis } from '../../types';
import { IndicatorEngine } from '../indicators';

export class PullbackEngine {
  private static readonly MIN_PULLBACK_DEPTH = 0.2;  // 20% of trend
  private static readonly MAX_PULLBACK_DEPTH = 0.5;  // 50% Fibonacci

  static analyze(snapshot: MarketSnapshot): PullbackAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const ema20 = IndicatorEngine.ema(closes, 20);
    const ema50 = IndicatorEngine.ema(closes, 50);

    // Detect if in pullback
    const pullbackState = this.detectPullback(closes, ema20, ema50);

    // Calculate pullback depth
    const depth = this.calculatePullbackDepth(closes, candles);

    // Determine if pullback is healthy
    const healthy = this.isHealthyPullback(pullbackState, depth, candles);

    // Calculate score
    const score = this.calculateScore(pullbackState, depth, healthy);

    const pass = pullbackState.inPullback && healthy && depth >= this.MIN_PULLBACK_DEPTH;

    const reasons: string[] = [];
    if (pullbackState.inPullback) {
      if (healthy) {
        reasons.push('Healthy pullback - good entry opportunity');
      } else {
        reasons.push('Pullback detected - check depth');
      }
      reasons.push(`Pullback depth: ${(depth * 100).toFixed(1)}%`);
    } else {
      reasons.push('No pullback in progress');
    }

    if (depth > this.MAX_PULLBACK_DEPTH) {
      reasons.push('⚠ Deep pullback - trend may be weakening');
    }

    return {
      score,
      pass,
      reasons,
      inPullback: pullbackState.inPullback,
      depth,
      healthy,
      details: {
        fibonacciLevel: this.getFibonacciLevel(depth),
        bounceLevel: pullbackState.bounceLevel,
        trendDirection: pullbackState.direction
      }
    };
  }

  private static detectPullback(
    closes: number[],
    ema20: number[],
    ema50: number[]
  ): { inPullback: boolean; direction: 'bull' | 'bear'; bounceLevel?: number } {
    const lastIdx = closes.length - 1;
    const currentPrice = closes[lastIdx];
    const currentEma20 = ema20[lastIdx] || currentPrice;
    const prevEma20 = ema20[Math.max(0, lastIdx - 5)] || currentEma20;

    // Uptrend with pullback: price was above EMA20, now approaching or below
    if (prevEma20 < currentEma20) { // EMA rising = uptrend
      // Check if price pulled back to EMA
      const aboveEma20 = currentPrice > currentEma20;
      const nearEma20 = Math.abs(currentPrice - currentEma20) / currentEma20 < 0.01;

      if (!aboveEma20 || nearEma20) {
        return {
          inPullback: true,
          direction: 'bull',
          bounceLevel: currentEma20
        };
      }
    }

    // Downtrend with pullback: price was below EMA20, now approaching or above
    if (prevEma20 > currentEma20) { // EMA falling = downtrend
      const belowEma20 = currentPrice < currentEma20;
      const nearEma20 = Math.abs(currentPrice - currentEma20) / currentEma20 < 0.01;

      if (!belowEma20 || nearEma20) {
        return {
          inPullback: true,
          direction: 'bear',
          bounceLevel: currentEma20
        };
      }
    }

    return { inPullback: false, direction: 'bull' };
  }

  private static calculatePullbackDepth(closes: number[], candles: Candle[]): number {
    const recent = candles.slice(-20);
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));
    const currentPrice = closes[closes.length - 1];

    const range = recentHigh - recentLow;
    if (range <= 0) return 0;

    // Calculate where current price is in the range
    // In uptrend: depth = how far price pulled back from high
    // In downtrend: depth = how far price pulled back from low
    const trendStart = closes[closes.length - 20];
    const isUptrend = closes[closes.length - 1] > trendStart;

    if (isUptrend) {
      return (recentHigh - currentPrice) / (recentHigh - recentLow);
    } else {
      return (currentPrice - recentLow) / (recentHigh - recentLow);
    }
  }

  private static isHealthyPullback(
    pullbackState: { inPullback: boolean; direction: string },
    depth: number,
    candles: Candle[]
  ): boolean {
    if (!pullbackState.inPullback) return false;

    // Check volume during pullback (should be lower than trend volume)
    const recent = candles.slice(-5);
    const earlier = candles.slice(-15, -5);
    const recentVol = recent.reduce((s, c) => s + c.volume, 0) / recent.length;
    const earlierVol = earlier.reduce((s, c) => s + c.volume, 0) / earlier.length;

    const volumeDeclining = recentVol < earlierVol * 1.2;

    // Check if pullback is not too deep
    const notDeep = depth <= this.MAX_PULLBACK_DEPTH;

    return volumeDeclining && notDeep;
  }

  private static calculateScore(
    pullbackState: { inPullback: boolean; direction: string },
    depth: number,
    healthy: boolean
  ): number {
    if (!pullbackState.inPullback) return 0;

    let score = 0;

    // Healthy pullback bonus
    if (healthy) {
      score = 20;
    } else {
      score = 5;
    }

    // Ideal depth bonus (around 38.2% - 50% Fib)
    if (depth >= 0.3 && depth <= 0.5) {
      score += 10;
    } else if (depth < this.MIN_PULLBACK_DEPTH) {
      score -= 5; // Too shallow
    } else if (depth > this.MAX_PULLBACK_DEPTH) {
      score -= 10; // Too deep
    }

    // Direction bonus
    if (pullbackState.direction === 'bull') {
      score += 5; // Bullish pullback slightly favored
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static getFibonacciLevel(depth: number): string {
    const fibLevels = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1];
    const fibNames = ['0%', '23.6%', '38.2%', '50%', '61.8%', '78.6%', '100%'];

    for (let i = fibLevels.length - 1; i >= 0; i--) {
      if (depth >= fibLevels[i]) {
        return fibNames[i];
      }
    }
    return '0%';
  }

  private static insufficientData(): PullbackAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for pullback analysis'],
      inPullback: false,
      depth: 0,
      healthy: false,
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  volume: number;
}
