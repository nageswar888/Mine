// Stability Engine - Measures market consistency versus randomness
// NEVER generates CALL/PUT signals

import { MarketSnapshot, EngineResult } from '../../types';

export class StabilityEngine {
  private static readonly LOOKBACK = 30;

  static analyze(snapshot: MarketSnapshot): EngineResult {
    const { candles } = snapshot;

    if (candles.length < 40) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const recent = candles.slice(-this.LOOKBACK);

    // Calculate stability metrics
    const directionalConsistency = this.calculateDirectionalConsistency(closes);
    const volumeConsistency = this.calculateVolumeConsistency(recent);
    const rangeConsistency = this.calculateRangeConsistency(recent);
    const overallStability = this.calculateOverallStability(
      directionalConsistency,
      volumeConsistency,
      rangeConsistency
    );

    // Calculate score
    const score = this.calculateScore(directionalConsistency, volumeConsistency, overallStability);

    const pass = overallStability >= 50 && directionalConsistency >= 40;

    const reasons: string[] = [];
    if (overallStability >= 70) {
      reasons.push('High market stability - predictable behavior');
    } else if (overallStability >= 50) {
      reasons.push('Moderate stability - acceptable conditions');
    } else {
      reasons.push('Low stability - unpredictable market behavior');
    }

    if (directionalConsistency >= 60) {
      reasons.push('Consistent price direction');
    }

    if (rangeConsistency < 40) {
      reasons.push('⚠ Inconsistent candle ranges');
    }

    return {
      score,
      pass,
      reasons,
      details: {
        directionalConsistency,
        volumeConsistency,
        rangeConsistency,
        overallStability,
        marketState: this.getMarketState(overallStability)
      }
    };
  }

  private static calculateDirectionalConsistency(closes: number[]): number {
    const recent = closes.slice(-this.LOOKBACK);
    let directionChanges = 0;
    let prevDir = recent[1] > recent[0] ? 1 : -1;

    for (let i = 2; i < recent.length; i++) {
      const dir = recent[i] > recent[i - 1] ? 1 : -1;
      if (dir !== prevDir) directionChanges++;
      prevDir = dir;
    }

    // Fewer changes = more consistent
    const maxChanges = recent.length;
    const consistency = 100 - (directionChanges / maxChanges) * 100;

    return Math.max(0, Math.min(100, consistency));
  }

  private static calculateVolumeConsistency(candles: Candle[]): number {
    const volumes = candles.map(c => c.volume).filter(v => v > 0);
    if (volumes.length < 5) return 50;

    const avg = volumes.reduce((a, b) => a + b, 0) / volumes.length;
    const variance = volumes.reduce((sum, v) => sum + Math.pow(v - avg, 2), 0) / volumes.length;
    const stdDev = Math.sqrt(variance);
    const cv = avg !== 0 ? (stdDev / avg) * 100 : 100; // Coefficient of variation

    // Lower CV = more consistent
    const consistency = Math.max(0, 100 - cv);
    return Math.min(100, consistency);
  }

  private static calculateRangeConsistency(candles: Candle[]): number {
    const ranges = candles.map(c => c.high - c.low);
    const avg = ranges.reduce((a, b) => a + b, 0) / ranges.length;

    // Calculate how many candles are within 50% of average range
    const withinRange = ranges.filter(r => r >= avg * 0.5 && r <= avg * 1.5).length;

    return Math.round((withinRange / ranges.length) * 100);
  }

  private static calculateOverallStability(
    directionalConsistency: number,
    volumeConsistency: number,
    rangeConsistency: number
  ): number {
    // Weight: direction 50%, volume 25%, range 25%
    return Math.round(
      directionalConsistency * 0.5 +
      volumeConsistency * 0.25 +
      rangeConsistency * 0.25
    );
  }

  private static calculateScore(
    directionalConsistency: number,
    volumeConsistency: number,
    overallStability: number
  ): number {
    let score = 0;

    // Stability contribution
    if (overallStability >= 70) score = 25;
    else if (overallStability >= 50) score = 10;
    else if (overallStability >= 30) score = -10;
    else score = -25;

    // Direction bonus
    if (directionalConsistency >= 70) score += 10;

    // Volume bonus
    if (volumeConsistency >= 70) score += 5;

    return Math.max(-100, Math.min(100, score));
  }

  private static getMarketState(stability: number): string {
    if (stability >= 70) return 'stable';
    if (stability >= 50) return 'moderate';
    if (stability >= 30) return 'choppy';
    return 'chaotic';
  }

  private static insufficientData(): EngineResult {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for stability analysis'],
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  volume: number;
}
