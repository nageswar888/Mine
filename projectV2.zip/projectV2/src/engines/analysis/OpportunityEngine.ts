// Opportunity Engine - Ranks setup quality
// NEVER generates CALL/PUT signals

import { MarketSnapshot, EngineResult, OpportunityRank } from '../../types';

export class OpportunityEngine {
  static analyze(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>
  ): EngineResult & { rank: OpportunityRank } {
    const { candles } = snapshot;

    if (candles.length < 20) {
      return this.insufficientData();
    }

    // Count bullish and bearish signals from all engines
    let bullishCount = 0;
    let bearishCount = 0;
    let totalStrength = 0;

    for (const [name, result] of Object.entries(engineResults)) {
      if (result.score > 20) bullishCount++;
      else if (result.score < -20) bearishCount++;

      totalStrength += Math.abs(result.score);
    }

    // Calculate quality
    const quality = this.calculateQuality(engineResults);

    // Calculate reward/risk
    const rewardRisk = this.calculateRewardRisk(candles, engineResults);

    // Calculate probability
    const probability = this.calculateProbability(quality, engineResults);

    // Calculate score
    const score = this.calculateScore(quality, rewardRisk, probability);

    const pass = quality >= 50;

    const reasons: string[] = [];
    if (quality >= 75) {
      reasons.push('High quality setup');
    } else if (quality >= 50) {
      reasons.push('Moderate quality setup');
    } else if (quality >= 25) {
      reasons.push('Low quality setup - consider skipping');
    } else {
      reasons.push('Poor setup quality - avoid');
    }

    if (rewardRisk >= 2) {
      reasons.push(`Good R:R ratio (${rewardRisk.toFixed(1)}:1)`);
    } else {
      reasons.push(`Suboptimal R:R ratio (${rewardRisk.toFixed(1)}:1)`);
    }

    return {
      score,
      pass,
      reasons,
      rank: { quality, rewardRisk, probability },
      details: {
        bullishCount,
        bearishCount,
        totalStrength,
        avgScore: this.calculateAverageScore(engineResults)
      }
    };
  }

  private static calculateQuality(engineResults: Record<string, EngineResult>): number {
    const engineCount = Object.keys(engineResults).length;
    if (engineCount === 0) return 0;

    let totalScore = 0;
    let passCount = 0;

    for (const result of Object.values(engineResults)) {
      totalScore += Math.abs(result.score);
      if (result.pass) passCount++;
    }

    // Quality based on:
    // 1. Percentage of engines passing
    // 2. Average score magnitude
    const passRate = (passCount / engineCount) * 100;
    const avgScore = totalScore / engineCount;

    // Weight: 60% pass rate, 40% average score
    const quality = passRate * 0.6 + Math.min(100, avgScore) * 0.4;

    return Math.round(quality);
  }

  private static calculateRewardRisk(
    candles: Candle[],
    engineResults: Record<string, EngineResult>
  ): number {
    const last = candles[candles.length - 1];

    // Estimate entry, stop, and target
    const recentHigh = Math.max(...candles.slice(-20).map(c => c.high));
    const recentLow = Math.min(...candles.slice(-20).map(c => c.low));
    const range = recentHigh - recentLow;

    // If bullish setup, target is high side, stop is low side
    let stopDistance: number;
    let targetDistance: number;

    const totalScore = Object.values(engineResults).reduce((s, r) => s + r.score, 0);

    if (totalScore > 0) {
      // Bullish - stop below recent low, target near high
      stopDistance = last.close - recentLow;
      targetDistance = recentHigh - last.close;
    } else {
      // Bearish - stop above recent high, target near low
      stopDistance = recentHigh - last.close;
      targetDistance = last.close - recentLow;
    }

    if (stopDistance <= 0) return 1;

    return Math.round((targetDistance / stopDistance) * 10) / 10;
  }

  private static calculateProbability(
    quality: number,
    engineResults: Record<string, EngineResult>
  ): number {
    // Base probability on quality
    let baseProb = quality * 0.7;

    // Adjust based on confluence
    const passCount = Object.values(engineResults).filter(r => r.pass).length;
    const engineCount = Object.keys(engineResults).length;
    const passRate = engineCount > 0 ? passCount / engineCount : 0;

    // Higher pass rate = higher probability
    const adjustment = (passRate - 0.5) * 20;

    return Math.max(10, Math.min(90, Math.round(baseProb + adjustment)));
  }

  private static calculateScore(
    quality: number,
    rewardRisk: number,
    probability: number
  ): number {
    let score = 0;

    // Quality contribution (0-40)
    score += (quality - 50) * 0.8;

    // R:R contribution
    if (rewardRisk >= 2) score += 15;
    else if (rewardRisk >= 1.5) score += 10;
    else if (rewardRisk < 1) score -= 10;

    // Probability contribution (scaled from 50)
    score += (probability - 50) * 0.3;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static calculateAverageScore(engineResults: Record<string, EngineResult>): number {
    const scores = Object.values(engineResults).map(r => r.score);
    if (scores.length === 0) return 0;
    return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  }

  private static insufficientData(): EngineResult & { rank: OpportunityRank } {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for opportunity analysis'],
      rank: { quality: 0, rewardRisk: 1, probability: 50 },
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  close: number;
}
