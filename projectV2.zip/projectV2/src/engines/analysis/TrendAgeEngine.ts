// Trend Age Engine - Determines if trend is fresh or exhausted
// NEVER generates CALL/PUT signals

import { MarketSnapshot, EngineResult } from '../../types';

export class TrendAgeEngine {
  private static readonly FRESH_THRESHOLD = 8;  // candles
  private static readonly EXHAUSTED_THRESHOLD = 20; // candles

  static analyze(snapshot: MarketSnapshot): EngineResult {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);

    // Determine trend age
    const trendAge = this.calculateTrendAge(closes);
    const exhaustion = this.calculateExhaustionStatus(candles);

    // Calculate score
    const score = this.calculateScore(trendAge, exhaustion);

    const pass = trendAge <= this.EXHAUSTED_THRESHOLD;

    const reasons: string[] = [];
    if (trendAge <= this.FRESH_THRESHOLD) {
      reasons.push('Fresh trend - good entry potential');
    } else if (trendAge >= this.EXHAUSTED_THRESHOLD) {
      reasons.push('⚠ Trend may be exhausted - be cautious');
    } else {
      reasons.push(`Trend age: ${trendAge} candles`);
    }

    if (exhaustion.divergence) {
      reasons.push('Divergence detected - momentum weakening');
    }

    return {
      score,
      pass,
      reasons,
      details: {
        trendAge,
        exhaustionScore: exhaustion.score,
        hasDivergence: exhaustion.divergence,
        candlesSinceHigh: exhaustion.candlesSinceHigh,
        candlesSinceLow: exhaustion.candlesSinceLow
      }
    };
  }

  private static calculateTrendAge(closes: number[]): number {
    // Find when current trend started
    let trendStart = 0;
    const currentDirection = closes[closes.length - 1] > closes[closes.length - 2] ? 'up' : 'down';

    for (let i = closes.length - 2; i > 0; i--) {
      const candleDirection = closes[i] > closes[i - 1] ? 'up' : 'down';
      if (candleDirection !== currentDirection) {
        trendStart = i;
        break;
      }
    }

    return closes.length - 1 - trendStart;
  }

  private static calculateExhaustionStatus(
    candles: Candle[]
  ): { score: number; divergence: boolean; candlesSinceHigh: number; candlesSinceLow: number } {
    const last = candles[candles.length - 1];
    const closes = candles.map(c => c.close);

    // Find recent swing high and low
    let candlesSinceHigh = 0;
    let candlesSinceLow = 0;

    for (let i = candles.length - 2; i >= 0; i--) {
      if (candles[i].high >= last.high) candlesSinceHigh++;
      else break;
    }

    for (let i = candles.length - 2; i >= 0; i--) {
      if (candles[i].low <= last.low) candlesSinceLow++;
      else break;
    }

    // Check for divergence (price higher but momentum lower)
    const recent = closes.slice(-10);
    const earlier = closes.slice(-20, -10);
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const earlierAvg = earlier.reduce((a, b) => a + b, 0) / earlier.length;

    const priceDirection = recentAvg > earlierAvg ? 'up' : 'down';

    // Simple momentum check
    const recentGain = Math.abs(recent[recent.length - 1] - recent[0]);
    const earlierGain = Math.abs(earlier[earlier.length - 1] - earlier[0]);

    const divergence = recentGain < earlierGain * 0.5 && Math.abs(recentAvg - earlierAvg) > 0;

    // Exhaustion score
    let score = 0;
    if (candlesSinceHigh > 5 && priceDirection === 'up') score += 20;
    if (candlesSinceLow > 5 && priceDirection === 'down') score += 20;
    if (divergence) score += 30;

    return { score, divergence, candlesSinceHigh, candlesSinceLow };
  }

  private static calculateScore(trendAge: number, exhaustion: { score: number }): number {
    let score = 0;

    // Fresh trend bonus
    if (trendAge <= this.FRESH_THRESHOLD) score = 30;
    else if (trendAge <= 12) score = 15;
    else if (trendAge >= this.EXHAUSTED_THRESHOLD) score = -25;

    // Exhaustion penalty
    score -= exhaustion.score;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): EngineResult {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for trend age analysis'],
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  close: number;
}
