// Momentum Engine - Determines momentum strength and divergence
// NEVER generates CALL/PUT signals
// ACCURACY FOCUS: Divergence detection + momentum sustainability

import { MarketSnapshot, MomentumAnalysis } from '../../types';
import { IndicatorEngine } from '../indicators';

export class MomentumEngine {
  static analyze(snapshot: MarketSnapshot): MomentumAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const rsiArray = IndicatorEngine.rsi(closes, 14);
    const macd = IndicatorEngine.macd(closes);

    const lastIdx = closes.length - 1;
    const currentRsi = rsiArray[rsiArray.length - 1] || 50;
    const histogram = macd.histogram[lastIdx] || 0;
    const histogramPrev3 = macd.histogram[lastIdx - 3] || 0;
    const macdLine = macd.macd[lastIdx] || 0;

    // Calculate momentum strength (sustained, not just current)
    const strength = this.calculateMomentumStrength(currentRsi, histogram, macdLine);

    // Detect divergence with multi-confirmation
    const divergence = this.detectDivergence(closes, rsiArray, macd.histogram);

    // Check momentum sustainability
    const sustainability = this.checkSustainability(macd.histogram, lastIdx);

    // Calculate score with accuracy emphasis
    const score = this.calculateScore(currentRsi, histogram, histogramPrev3, divergence, sustainability);

    // STRICT PASS: strong momentum + no divergence + sustainable
    const pass = strength >= 50 &&
                 !divergence.detected &&
                 sustainability &&
                 Math.abs(score) >= 15;

    const reasons: string[] = [];
    if (histogram > 0) {
      reasons.push('Bullish MACD histogram');
    } else if (histogram < 0) {
      reasons.push('Bearish MACD histogram');
    }

    // RSI context
    if (currentRsi > 60 && currentRsi < 75) {
      reasons.push('RSI in bullish zone (60-75)');
    } else if (currentRsi < 40 && currentRsi > 25) {
      reasons.push('RSI in bearish zone (25-40)');
    } else if (currentRsi >= 75) {
      reasons.push('⚠ RSI overbought');
    } else if (currentRsi <= 25) {
      reasons.push('⚠ RSI oversold');
    }

    if (divergence.detected) {
      reasons.push(`⚠ ${divergence.divergenceType} divergence - reversal risk`);
    }

    if (!sustainability) {
      reasons.push('⚠ Momentum weakening');
    } else {
      reasons.push('Momentum sustainable');
    }

    return {
      score,
      pass,
      reasons,
      strength,
      divergence: divergence.detected,
      divergenceType: divergence.divergenceType,
      details: {
        rsi: currentRsi,
        macdHistogram: histogram,
        histogramTrend: histogram > histogramPrev3 ? 'increasing' : 'decreasing',
        sustainability
      }
    };
  }

  private static calculateMomentumStrength(rsi: number, histogram: number, macdLine: number): number {
    // RSI momentum (distance from 50, max 40)
    const rsiStrength = Math.abs(rsi - 50) * 0.8;

    // MACD histogram strength (max 30)
    const histogramStrength = Math.min(30, Math.abs(histogram) * 30000);

    // MACD line direction (max 20)
    const macdStrength = Math.min(20, Math.abs(macdLine) * 10000);

    // Bonus for alignment (RSI and MACD agree)
    const alignment = (rsi > 50 && histogram > 0) || (rsi < 50 && histogram < 0);
    const alignmentBonus = alignment ? 10 : 0;

    return Math.round(rsiStrength + histogramStrength + macdStrength + alignmentBonus);
  }

  private static detectDivergence(
    closes: number[],
    rsi: number[],
    histogram: number[]
  ): { detected: boolean; divergenceType?: 'bullish' | 'bearish' } {
    const lookback = 20;
    const recentCloses = closes.slice(-lookback);
    const recentRsi = rsi.slice(-lookback);
    const recentHist = histogram.slice(-lookback);

    // Find swing points
    const priceSwings = this.findSwingPoints(recentCloses);

    if (priceSwings.length < 2) return { detected: false };

    // Check for bearish divergence (price HH, RSI/MACD LH)
    const lastHigh = priceSwings.filter(s => s.type === 'high').slice(-2);
    if (lastHigh.length === 2) {
      const priceMadeHH = lastHigh[1].price > lastHigh[0].price;
      const rsiMadeLH = recentRsi[rsi.length - 1] < recentRsi[lastHigh[0].index];
      const histMadeLH = Math.abs(recentHist[recentHist.length - 1]) < Math.abs(recentHist[lastHigh[0].index]);

      if (priceMadeHH && (rsiMadeLH || histMadeLH)) {
        return { detected: true, divergenceType: 'bearish' };
      }
    }

    // Check for bullish divergence (price LL, RSI/MACD HL)
    const lastLow = priceSwings.filter(s => s.type === 'low').slice(-2);
    if (lastLow.length === 2) {
      const priceMadeLL = lastLow[1].price < lastLow[0].price;
      const rsiMadeHL = recentRsi[rsi.length - 1] > recentRsi[lastLow[0].index];
      const histMadeHL = Math.abs(recentHist[recentHist.length - 1]) < Math.abs(recentHist[lastLow[0].index]);

      if (priceMadeLL && (rsiMadeHL || histMadeHL)) {
        return { detected: true, divergenceType: 'bullish' };
      }
    }

    // Additional check: histogram exhaustion
    const histMax = Math.max(...recentHist.map(Math.abs));
    const currentHist = Math.abs(recentHist[recentHist.length - 1]);
    if (currentHist < histMax * 0.4 && currentHist > 0) {
      // Histogram weakening significantly
      const priceDirection = recentCloses[recentCloses.length - 1] > recentCloses[0];
      if (priceDirection) {
        return { detected: true, divergenceType: 'bearish' };
      } else {
        return { detected: true, divergenceType: 'bullish' };
      }
    }

    return { detected: false };
  }

  private static findSwingPoints(arr: number[]): Array<{ index: number; price: number; type: 'high' | 'low' }> {
    const swings: Array<{ index: number; price: number; type: 'high' | 'low' }> = [];

    for (let i = 2; i < arr.length - 2; i++) {
      // Swing high
      if (arr[i] > arr[i - 1] && arr[i] > arr[i + 1] &&
          arr[i] > arr[i - 2] && arr[i] > arr[i + 2]) {
        swings.push({ index: i, price: arr[i], type: 'high' });
      }
      // Swing low
      if (arr[i] < arr[i - 1] && arr[i] < arr[i + 1] &&
          arr[i] < arr[i - 2] && arr[i] < arr[i + 2]) {
        swings.push({ index: i, price: arr[i], type: 'low' });
      }
    }

    return swings;
  }

  private static checkSustainability(histogram: number[], lastIdx: number): boolean {
    // Check if momentum is building or depleting
    const recent5 = histogram.slice(-5);
    const prev5 = histogram.slice(-10, -5);

    const recentAvg = Math.abs(recent5.reduce((a, b) => a + b, 0) / 5);
    const prevAvg = Math.abs(prev5.reduce((a, b) => a + b, 0) / 5);

    // Sustainable if momentum is increasing or stable
    return recentAvg >= prevAvg * 0.7;
  }

  private static calculateScore(
    rsi: number,
    histogram: number,
    histogramPrev3: number,
    divergence: { detected: boolean; divergenceType?: 'bullish' | 'bearish' },
    sustainability: boolean
  ): number {
    let score = 0;

    // RSI contribution (moderated)
    if (rsi > 50 && rsi < 75) {
      score += (rsi - 50) * 0.6;
    } else if (rsi < 50 && rsi > 25) {
      score -= (50 - rsi) * 0.6;
    } else if (rsi >= 75) {
      score -= 10; // Overbought penalty
    } else if (rsi <= 25) {
      score += 10; // Oversold reversal potential
    }

    // MACD histogram contribution
    score += histogram * 15000;

    // Histogram momentum direction
    if (histogram > 0 && histogram > histogramPrev3) score += 15;
    else if (histogram < 0 && histogram < histogramPrev3) score -= 15;

    // Divergence penalty (major accuracy factor)
    if (divergence.detected) {
      if (divergence.divergenceType === 'bullish') {
        // Bullish divergence after downtrend = potential up move
        score = Math.max(score, 20);
      } else if (divergence.divergenceType === 'bearish') {
        // Bearish divergence after uptrend = potential down move
        score = Math.min(score, -20);
      }
    }

    // Sustainability bonus
    if (!sustainability) score *= 0.6;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): MomentumAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for momentum analysis'],
      strength: 0,
      divergence: false,
      details: { sustainability: false }
    };
  }
}
