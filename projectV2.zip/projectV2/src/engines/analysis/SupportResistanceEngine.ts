// Support & Resistance Engine - Determines dynamic S/R levels
// NEVER generates CALL/PUT signals

import { MarketSnapshot, SupportResistanceAnalysis } from '../../types';

export class SupportResistanceEngine {
  private static readonly LOOKBACK = 50;
  private static readonly TOUCH_THRESHOLD = 0.002; // 0.2% tolerance for touches

  static analyze(snapshot: MarketSnapshot): SupportResistanceAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const highs = candles.map(c => c.high);
    const lows = candles.map(c => c.low);
    const currentPrice = closes[closes.length - 1];

    // Find levels using swing points and multi-touch zones
    const levels = this.findLevels(highs, lows, closes);

    // Find nearest levels
    const { nearestSupport, nearestResistance, distanceToNearest } =
      this.findNearestLevels(currentPrice, levels);

    // Calculate score
    const score = this.calculateScore(currentPrice, nearestSupport, nearestResistance, distanceToNearest);

    const pass = distanceToNearest > 0.5 && levels.length >= 2;

    const reasons: string[] = [];
    const strongLevels = levels.filter(l => l.strength > 60);
    if (strongLevels.length >= 2) {
      reasons.push(`${strongLevels.length} strong S/R levels detected`);
    }

    if (distanceToNearest < 0.3) {
      reasons.push('⚠ Price near key level - watch for reaction');
    } else {
      reasons.push('Price away from major levels');
    }

    return {
      score,
      pass,
      reasons,
      levels,
      nearestSupport,
      nearestResistance,
      distanceToNearest,
      details: {
        levelCount: levels.length,
        strongLevelCount: strongLevels.length,
        positionVsLevels: this.getPricePosition(currentPrice, nearestSupport, nearestResistance)
      }
    };
  }

  private static findLevels(
    highs: number[],
    lows: number[],
    closes: number[]
  ): Array<{ price: number; type: 'support' | 'resistance'; strength: number; touches: number }> {
    const lookback = Math.min(this.LOOKBACK, highs.length - 1);
    const recentHighs = highs.slice(-lookback);
    const recentLows = lows.slice(-lookback);
    const recentCloses = closes.slice(-lookback);

    const levels: Map<number, { count: number; asHigh: number; asLow: number }> = new Map();

    // Group similar prices into zones
    const tolerance = (recentHighs[recentHighs.length - 1] * this.TOUCH_THRESHOLD);

    // Find pivot highs and lows
    for (let i = 2; i < recentHighs.length - 2; i++) {
      if (recentHighs[i] > recentHighs[i - 1] && recentHighs[i] > recentHighs[i + 1] &&
          recentHighs[i] > recentHighs[i - 2] && recentHighs[i] > recentHighs[i + 2]) {
        this.addLevel(levels, recentHighs[i], tolerance, true);
      }

      if (recentLows[i] < recentLows[i - 1] && recentLows[i] < recentLows[i + 1] &&
          recentLows[i] < recentLows[i - 2] && recentLows[i] < recentLows[i + 2]) {
        this.addLevel(levels, recentLows[i], tolerance, false);
      }
    }

    // Also consider high-volume close zones
    for (const close of recentCloses) {
      this.addLevel(levels, close, tolerance, true, 0.3); // Lower weight for closes
    }

    // Convert to array and determine type
    const result: Array<{ price: number; type: 'support' | 'resistance'; strength: number; touches: number }> = [];

    for (const [price, data] of levels) {
      if (data.count < 2) continue; // Need at least 2 touches

      const type = data.asHigh >= data.asLow ? 'resistance' : 'support';
      const strength = Math.min(100, data.count * 20 + Math.max(data.asHigh, data.asLow) * 15);

      result.push({ price, type, strength, touches: data.count });
    }

    // Sort by strength
    return result.sort((a, b) => b.strength - a.strength).slice(0, 8);
  }

  private static addLevel(
    levels: Map<number, { count: number; asHigh: number; asLow: number }>,
    price: number,
    tolerance: number,
    isHigh: boolean,
    weight: number = 1
  ): void {
    // Find existing level within tolerance
    for (const [existingPrice, data] of levels) {
      if (Math.abs(existingPrice - price) < tolerance) {
        data.count += weight;
        if (isHigh) data.asHigh += weight;
        else data.asLow += weight;
        return;
      }
    }

    // Create new level
    levels.set(price, {
      count: weight,
      asHigh: isHigh ? weight : 0,
      asLow: isHigh ? 0 : weight
    });
  }

  private static findNearestLevels(
    currentPrice: number,
    levels: Array<{ price: number; type: 'support' | 'resistance'; strength: number; touches: number }>
  ): { nearestSupport: number; nearestResistance: number; distanceToNearest: number } {
    const supports = levels.filter(l => l.type === 'support' && l.price < currentPrice);
    const resistances = levels.filter(l => l.type === 'resistance' && l.price > currentPrice);

    const nearestSupport = supports.length > 0
      ? Math.max(...supports.map(l => l.price))
      : currentPrice * 0.98;

    const nearestResistance = resistances.length > 0
      ? Math.min(...resistances.map(l => l.price))
      : currentPrice * 1.02;

    const distToSupport = ((currentPrice - nearestSupport) / currentPrice) * 100;
    const distToResistance = ((nearestResistance - currentPrice) / currentPrice) * 100;
    const distanceToNearest = Math.min(distToSupport, distToResistance);

    return { nearestSupport, nearestResistance, distanceToNearest };
  }

  private static calculateScore(
    currentPrice: number,
    nearestSupport: number,
    nearestResistance: number,
    distanceToNearest: number
  ): number {
    let score = 0;

    // Being near support can be bullish
    const distToSupport = ((currentPrice - nearestSupport) / currentPrice) * 100;
    const distToResistance = ((nearestResistance - currentPrice) / currentPrice) * 100;

    // Price bouncing off support
    if (distToSupport < 0.5 && distToSupport > -0.5) {
      score += 20;
    }

    // Price at resistance
    if (distToResistance < 0.5) {
      score -= 15;
    }

    // Room to move (middle of range)
    const range = nearestResistance - nearestSupport;
    const midPoint = (nearestSupport + nearestResistance) / 2;
    const positionInRange = range !== 0 ? (currentPrice - nearestSupport) / range : 0.5;

    if (positionInRange > 0.3 && positionInRange < 0.7) {
      score += 10; // Good position in range
    }

    // Distance to nearest level
    if (distanceToNearest > 1) {
      score += 15; // Good distance from levels
    } else if (distanceToNearest < 0.3) {
      score -= 10; // Too close to level
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static getPricePosition(
    currentPrice: number,
    nearestSupport: number,
    nearestResistance: number
  ): string {
    const range = nearestResistance - nearestSupport;
    if (range <= 0) return 'at_level';

    const position = (currentPrice - nearestSupport) / range;

    if (position < 0.1) return 'at_support';
    if (position > 0.9) return 'at_resistance';
    if (position < 0.35) return 'near_support';
    if (position > 0.65) return 'near_resistance';
    return 'mid_range';
  }

  private static insufficientData(): SupportResistanceAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for S/R analysis'],
      levels: [],
      nearestSupport: 0,
      nearestResistance: 0,
      distanceToNearest: 100,
      details: {}
    };
  }
}
