// Trend Slope Engine - Measures trend acceleration
// NEVER generates CALL/PUT signals

import { MarketSnapshot, EngineResult } from '../../types';
import { IndicatorEngine } from '../indicators';

export class TrendSlopeEngine {
  static analyze(snapshot: MarketSnapshot): EngineResult {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const ema20 = IndicatorEngine.ema(closes, 20);

    // Calculate slope at different periods
    const slope5 = this.calculateSlope(ema20, 5);
    const slope10 = this.calculateSlope(ema20, 10);
    const slope20 = this.calculateSlope(ema20, 20);

    // Calculate acceleration
    const acceleration = this.calculateAcceleration(slope5, slope10, slope20);

    // Calculate score
    const score = this.calculateScore(slope5, slope10, slope20, acceleration);

    const pass = Math.abs(slope10) > 0.01 && Math.abs(acceleration) < 0.1;

    const reasons: string[] = [];
    if (slope5 > 0.02) {
      reasons.push('Strong bullish slope');
    } else if (slope5 < -0.02) {
      reasons.push('Strong bearish slope');
    } else if (Math.abs(slope5) < 0.005) {
      reasons.push('Flat trend - low momentum');
    } else {
      reasons.push('Moderate trend slope');
    }

    if (acceleration > 0.01) {
      reasons.push('Trend accelerating');
    } else if (acceleration < -0.01) {
      reasons.push('Trend decelerating');
    }

    return {
      score,
      pass,
      reasons,
      details: {
        slope5: +(slope5 * 100).toFixed(4),
        slope10: +(slope10 * 100).toFixed(4),
        slope20: +(slope20 * 100).toFixed(4),
        acceleration: +(acceleration * 100).toFixed(4),
        trendStrength: Math.abs(slope10) > 0.15 ? 'strong' : Math.abs(slope10) > 0.05 ? 'moderate' : 'weak'
      }
    };
  }

  private static calculateSlope(ema: number[], period: number): number {
    const lastIdx = ema.length - 1;
    if (lastIdx < period) return 0;

    const current = ema[lastIdx] || 0;
    const previous = ema[lastIdx - period] || current;
    const avg = (current + previous) / 2;

    return avg !== 0 ? (current - previous) / (avg * period) : 0;
  }

  private static calculateAcceleration(slope5: number, slope10: number, slope20: number): number {
    // Acceleration is the rate of change of slope
    // If slope5 > slope10, trend is accelerating
    // If slope5 < slope10, trend is decelerating
    return slope5 - (slope10 + slope20) / 2;
  }

  private static calculateScore(slope5: number, slope10: number, slope20: number, acceleration: number): number {
    let score = 0;

    // Slope direction and strength contribution
    if (slope10 > 0) {
      score += Math.min(30, slope10 * 500);
    } else if (slope10 < 0) {
      score -= Math.min(30, Math.abs(slope10) * 500);
    }

    // Consistency bonus (all slopes same direction)
    if (slope5 > 0 && slope10 > 0 && slope20 > 0) score += 10;
    if (slope5 < 0 && slope10 < 0 && slope20 < 0) score -= 10;

    // Acceleration modifier
    if (slope10 > 0 && acceleration > 0) score += 5;
    if (slope10 < 0 && acceleration < 0) score -= 5;

    // Rapid deceleration warning
    if (acceleration < -0.05) score *= 0.7;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): EngineResult {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for trend slope analysis'],
      details: {}
    };
  }
}
