import { MarketSnapshot, MarketContextAnalysis, EngineResult, VolatilityAnalysis } from '../../types';

export class MarketContextEngine {
  static analyze(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>
  ): MarketContextAnalysis {
    const trend = engineResults['trend'];
    const momentum = engineResults['momentum'];
    const structure = engineResults['structure'];
    const regime = engineResults['regime'];
    const volatility = engineResults['volatility'];
    const liquidity = engineResults['liquidity'];

    if (!trend || !momentum || !structure || !regime || !volatility || !liquidity) {
      return this.insufficientData();
    }

    const trendScore = trend.score;
    const momentumScore = momentum.score;
    const structureScore = structure.score;
    const regimeScore = regime.score;
    const volatilityScore = volatility.score;
    const liquidityScore = liquidity.score;

    const weightedTotal =
      trendScore * 0.25 +
      momentumScore * 0.2 +
      structureScore * 0.2 +
      regimeScore * 0.15 +
      volatilityScore * 0.1 +
      liquidityScore * 0.1;

    const volatilityAnalysis = volatility as VolatilityAnalysis;
    const contextScore = Math.max(-100, Math.min(100, Math.round(weightedTotal)));
    const state = this.determineState(trendScore, momentumScore, structureScore, regimeScore, volatilityScore, liquidityScore);
    const healthy = state === 'Trending' && volatilityAnalysis.state === 'healthy' && liquidity.pass && trend.pass;

    const reasons: string[] = [];
    if (state === 'Trending') {
      reasons.push('Market is in a healthy trending condition');
    } else if (state === 'Transition') {
      reasons.push('Market is shifting - watch for direction change');
    } else if (state === 'Sideways') {
      reasons.push('Market is rangebound - expect choppy price action');
    } else if (state === 'Exhausted') {
      reasons.push('Market may be exhausted after a move');
    }

    if (volatilityAnalysis.state !== 'healthy') {
      reasons.push('Volatility is not ideal for trend entries');
    }

    if (liquidity.details?.event === 'fake_breakout') {
      reasons.push('Liquidity signals indicate potential fake breakout');
    }

    return {
      score: contextScore,
      pass: healthy,
      reasons,
      state,
      contextScore: Math.max(0, Math.min(100, Math.round((contextScore + 100) / 2))),
      healthy,
      details: {
        trend: trendScore,
        momentum: momentumScore,
        structure: structureScore,
        regime: regimeScore,
        volatility: volatilityScore,
        liquidity: liquidityScore
      }
    };
  }

  private static determineState(
    trendScore: number,
    momentumScore: number,
    structureScore: number,
    regimeScore: number,
    volatilityScore: number,
    liquidityScore: number
  ): 'Trending' | 'Transition' | 'Sideways' | 'Exhausted' {
    if (trendScore > 20 && momentumScore > 15 && structureScore > 0 && regimeScore > 0 && volatilityScore > -20 && liquidityScore > -20) {
      return 'Trending';
    }

    if (trendScore > -10 && momentumScore > -10 && regimeScore > -10) {
      return 'Transition';
    }

    if (Math.abs(trendScore) < 15 && Math.abs(momentumScore) < 15 && regimeScore < 10) {
      return 'Sideways';
    }

    return 'Exhausted';
  }

  private static insufficientData(): MarketContextAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for market context analysis'],
      state: 'Transition',
      contextScore: 50,
      healthy: false,
      details: {
        trend: 0,
        momentum: 0,
        structure: 0,
        regime: 0,
        volatility: 0,
        liquidity: 0
      }
    };
  }
}
