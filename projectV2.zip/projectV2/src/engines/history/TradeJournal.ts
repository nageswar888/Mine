// Trade Journal - Stores every generated signal
// This layer never changes live signals

import { TradeRecord, Decision, Timeframe, SessionStats } from '../../types';

export class TradeJournal {
  private trades: TradeRecord[] = [];
  private maxTrades: number = 1000;

  record(decision: Decision, output: {
    tradeScore: number;
    confidence: number;
    reasons: string[];
    timestamp: number;
    risk: { totalRisk: number; recommendation: string };
    confluence: { agreement: number; bullishEngines: number; bearishEngines: number };
    validation: { approved: boolean; mandatoryChecksPassed: number; mandatoryChecksTotal: number };
  }, pair: string, timeframe: Timeframe, price: number, engineResults: Record<string, any>): TradeRecord {
    const record: TradeRecord = {
      id: this.generateId(),
      pair,
      timeframe,
      decision,
      tradeScore: output.tradeScore,
      confidence: output.confidence,
      price,
      reasons: output.reasons,
      timestamp: output.timestamp,
      engineResults: engineResults
    };

    this.trades.unshift(record);

    // Keep only recent trades
    if (this.trades.length > this.maxTrades) {
      this.trades = this.trades.slice(0, this.maxTrades);
    }

    return record;
  }

  getAll(): TradeRecord[] {
    return [...this.trades];
  }

  getRecent(count: number = 50): TradeRecord[] {
    return this.trades.slice(0, count);
  }

  getByPair(pair: string): TradeRecord[] {
    return this.trades.filter(t => t.pair === pair);
  }

  getByDecision(decision: Decision): TradeRecord[] {
    return this.trades.filter(t => t.decision === decision);
  }

  getByTimeframe(timeframe: Timeframe): TradeRecord[] {
    return this.trades.filter(t => t.timeframe === timeframe);
  }

  getSessionStats(): SessionStats {
    const total = this.trades.length;
    const calls = this.trades.filter(t => t.decision === 'CALL').length;
    const puts = this.trades.filter(t => t.decision === 'PUT').length;
    const waits = this.trades.filter(t => t.decision === 'WAIT').length;

    const withDecision = this.trades.filter(t => t.decision !== 'WAIT');
    const avgConfidence = withDecision.length > 0
      ? withDecision.reduce((s, t) => s + t.confidence, 0) / withDecision.length
      : 0;

    const avgTradeScore = total > 0
      ? this.trades.reduce((s, t) => s + t.tradeScore, 0) / total
      : 0;

    return {
      total,
      calls,
      puts,
      waits,
      avgConfidence: Math.round(avgConfidence),
      avgTradeScore: Math.round(avgTradeScore)
    };
  }

  getPairStats(pair: string): SessionStats {
    const pairTrades = this.getByPair(pair);
    const total = pairTrades.length;
    const calls = pairTrades.filter(t => t.decision === 'CALL').length;
    const puts = pairTrades.filter(t => t.decision === 'PUT').length;
    const waits = pairTrades.filter(t => t.decision === 'WAIT').length;

    const withDecision = pairTrades.filter(t => t.decision !== 'WAIT');
    const avgConfidence = withDecision.length > 0
      ? withDecision.reduce((s, t) => s + t.confidence, 0) / withDecision.length
      : 0;

    const avgTradeScore = total > 0
      ? pairTrades.reduce((s, t) => s + t.tradeScore, 0) / total
      : 0;

    return {
      total,
      calls,
      puts,
      waits,
      avgConfidence: Math.round(avgConfidence),
      avgTradeScore: Math.round(avgTradeScore)
    };
  }

  clear(): void {
    this.trades = [];
  }

  export(): string {
    return JSON.stringify(this.trades, null, 2);
  }

  import(data: string): boolean {
    try {
      const imported = JSON.parse(data);
      if (Array.isArray(imported)) {
        this.trades = imported;
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
}
