import { MarketSnapshot, EliteAnalysis, EngineResult, ConfluenceResult, RiskAssessment, ValidationResult, HistoricalProbabilityAnalysis, MarketContextAnalysis, EntryAnalysis } from '../../types';

export class EliteEngine {
  static analyze(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>,
    risk: RiskAssessment,
    confluence: ConfluenceResult,
    validation: ValidationResult,
    marketContext: MarketContextAnalysis,
    entry: EntryAnalysis,
    historicalProbability: HistoricalProbabilityAnalysis
  ): EliteAnalysis {
    const trend = engineResults['trend'];
    const momentum = engineResults['momentum'];
    const structure = engineResults['structure'];

    const criteria = [
      trend?.score !== undefined && trend?.pass,
      momentum?.score !== undefined && momentum?.pass,
      structure?.score !== undefined && structure?.pass,
      risk.recommendation === 'low',
      validation.approved,
      marketContext.healthy,
      entry.valid,
      historicalProbability.probability >= 55
    ];

    const trueCount = criteria.filter(Boolean).length;
    const elite = trueCount >= 6;
    const stars = Math.min(5, Math.max(0, trueCount - 2));

    const reasons: string[] = [];
    if (elite) {
      reasons.push('Elite setup: multiple quality thresholds satisfied');
    } else {
      reasons.push('Not elite: some quality thresholds were not met');
    }

    if (!trend?.pass) reasons.push('Trend conditions are not strong enough');
    if (!momentum?.pass) reasons.push('Momentum is not sufficiently supported');
    if (!structure?.pass) reasons.push('Structure is not clearly aligned');
    if (risk.recommendation !== 'low') reasons.push('Risk recommendation is not low');
    if (!marketContext.healthy) reasons.push('Market context is not healthy');
    if (!entry.valid) reasons.push('Entry conditions are invalid');
    if (historicalProbability.probability < 55) reasons.push('Historical probability is not strong enough');

    return {
      score: elite ? 80 : 20,
      pass: elite,
      reasons,
      elite,
      stars,
      details: {
        trueCriteria: trueCount,
        requiredCriteria: 6,
        probability: historicalProbability.probability,
        reliability: historicalProbability.reliability
      }
    };
  }
}
