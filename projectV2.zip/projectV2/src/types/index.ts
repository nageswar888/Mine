// Core Types for SignalX Decision Engine

export type Decision = 'CALL' | 'PUT' | 'WAIT';

export type Timeframe = '5min' | '15min';

export type MarketRegime = 'trending' | 'sideways' | 'consolidation' | 'transition';

export type VolatilityState = 'healthy' | 'low' | 'extreme';

export type StructureType = 'HH' | 'HL' | 'LH' | 'LL' | 'BOS' | 'CHoCH' | 'none';

export type TrendDirection = 'bullish' | 'bearish' | 'neutral';

export type CandlePattern = 'engulfing' | 'hammer' | 'doji' | 'pin_bar' | 'none';

export type LiquidityEvent = 'sweep' | 'fake_breakout' | 'stop_hunt' | 'none';

export type Session = 'asia' | 'london' | 'new_york' | 'overlap' | 'off';

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number;
}

export interface MarketSnapshot {
  pair: string;
  timeframe: Timeframe;
  candles: Candle[];
  currentPrice: number;
  timestamp: number;
  latestCandleTimestamp: number;
}

export interface EngineResult {
  score: number;          // -100 to 100
  pass: boolean;
  reasons: string[];
  details: Record<string, unknown>;
}

export interface IndicatorValues {
  ema20: number;
  ema50: number;
  ema200: number;
  rsi: number;
  macd: { macd: number; signal: number; histogram: number };
  atr: number;
  adx: number;
  bollingerBands: { upper: number; middle: number; lower: number; percentB: number };
  stochastic: { k: number; d: number };
  obv: number;
  vwap: number;
}

export interface TrendAnalysis extends EngineResult {
  direction: TrendDirection;
  strength: number;  // 0-100
  slope: number;
  age: 'fresh' | 'mature' | 'exhausted';
}

export interface MomentumAnalysis extends EngineResult {
  strength: number;
  divergence: boolean;
  divergenceType?: 'bullish' | 'bearish';
}

export interface StructureAnalysis extends EngineResult {
  pattern: StructureType;
  breaksStructure: boolean;
  higherHighs: number;
  higherLows: number;
  lowerHighs: number;
  lowerLows: number;
}

export interface VolatilityAnalysis extends EngineResult {
  state: VolatilityState;
  atrPercentile: number;
  expansionRate: number;
}

export type MarketContextState = 'Trending' | 'Transition' | 'Sideways' | 'Exhausted';

export type ExpiryRecommendation = 'short' | 'medium' | 'long' | 'none';

export interface MarketContextAnalysis extends EngineResult {
  state: MarketContextState;
  contextScore: number;
  healthy: boolean;
  details: {
    trend: number;
    momentum: number;
    structure: number;
    regime: number;
    volatility: number;
    liquidity: number;
  };
}

export interface EntryAnalysis extends EngineResult {
  entryPrice: number;
  entryDelay: number;
  entryWindow: number;
  valid: boolean;
  expiryRecommendation: ExpiryRecommendation;
}

export interface HistoricalProbabilityAnalysis extends EngineResult {
  probability: number;
  sampleSize: number;
  reliability: number;
}

export interface EliteAnalysis extends EngineResult {
  elite: boolean;
  stars: number;
}

export interface AdaptiveSuggestionAnalysis extends EngineResult {
  suggestions: string[];
}

export interface RegimeAnalysis extends EngineResult {
  regime: MarketRegime;
  trendingScore: number;
  sidewaysScore: number;
}

export interface SupportResistanceAnalysis extends EngineResult {
  levels: Array<{ price: number; type: 'support' | 'resistance'; strength: number; touches: number }>;
  nearestSupport: number;
  nearestResistance: number;
  distanceToNearest: number;
}

export interface CandlestickAnalysis extends EngineResult {
  pattern: CandlePattern;
  bullish: boolean;
  location: string;
}

export interface LiquidityAnalysis extends EngineResult {
  event: LiquidityEvent;
  sweptLevel?: number;
  fakeoutDetected: boolean;
}

export interface SessionAnalysis extends EngineResult {
  current: Session;
  active: boolean;
  liquidity: number;  // 0-100
}

export interface PullbackAnalysis extends EngineResult {
  inPullback: boolean;
  depth: number;
  healthy: boolean;
}

export interface BreakoutAnalysis extends EngineResult {
  confirmed: boolean;
  direction: 'up' | 'down' | 'none';
  retest: boolean;
}

export interface OpportunityRank {
  quality: number;      // 0-100
  rewardRisk: number;
  probability: number;
}

export interface RiskAssessment extends EngineResult {
  marketRisk: number;     // 0-100
  trendRisk: number;
  volatilityRisk: number;
  liquidityRisk: number;
  entryRisk: number;
  totalRisk: number;
  recommendation: 'low' | 'moderate' | 'high' | 'extreme';
}

export interface ConfluenceResult {
  agreement: number;      // 0-100
  bullishEngines: number;
  bearishEngines: number;
  neutralEngines: number;
  keyAlignments: string[];
  contradictions: string[];
}

export interface ValidationResult {
  approved: boolean;
  vetoes: string[];
  warnings: string[];
  mandatoryChecksPassed: number;
  mandatoryChecksTotal: number;
}

export interface DecisionOutput {
  decision: Decision;
  tradeScore: number;     // Setup quality 0-100
  confidence: number;     // Certainty 0-100
  reasons: string[];
  risk: RiskAssessment;
  confluence: ConfluenceResult;
  validation: ValidationResult;
  timestamp: number;
}

export interface TradeRecord {
  id: string;
  pair: string;
  timeframe: Timeframe;
  decision: Decision;
  tradeScore: number;
  confidence: number;
  price: number;
  reasons: string[];
  timestamp: number;
  engineResults: Record<string, EngineResult>;
}

export interface SessionStats {
  total: number;
  calls: number;
  puts: number;
  waits: number;
  avgConfidence: number;
  avgTradeScore: number;
}
