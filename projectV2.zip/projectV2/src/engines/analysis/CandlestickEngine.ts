// Candlestick Engine - Recognizes candlestick patterns
// NEVER generates CALL/PUT signals

import { MarketSnapshot, CandlestickAnalysis, CandlePattern } from '../../types';

export class CandlestickEngine {
  static analyze(snapshot: MarketSnapshot): CandlestickAnalysis {
    const { candles } = snapshot;

    if (candles.length < 5) {
      return this.insufficientData();
    }

    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];
    const recent = candles.slice(-10);

    // Detect patterns
    const pattern = this.detectPattern(last, prev, recent);
    const bullish = this.isPatternBullish(pattern, last, prev);

    // Determine location context
    const location = this.determineLocation(last, candles);

    // Calculate score
    const score = this.calculateScore(pattern, bullish, location);

    const pass = pattern !== 'none' && Math.abs(score) >= 10;

    const reasons: string[] = [];
    if (pattern === 'engulfing') {
      reasons.push(bullish ? 'Bullish engulfing pattern' : 'Bearish engulfing pattern');
    } else if (pattern === 'hammer') {
      reasons.push('Hammer pattern - potential reversal');
    } else if (pattern === 'doji') {
      reasons.push('Doji - indecision in market');
    } else if (pattern === 'pin_bar') {
      reasons.push(bullish ? 'Bullish pin bar' : 'Bearish pin bar');
    } else {
      reasons.push('No significant candlestick pattern');
    }

    if (location === 'at_support' || location === 'at_resistance') {
      reasons.push(`Pattern at key ${location === 'at_support' ? 'support' : 'resistance'}`);
    }

    return {
      score,
      pass,
      reasons,
      pattern,
      bullish,
      location,
      details: {
        bodySize: Math.abs(last.close - last.open),
        upperWick: last.high - Math.max(last.open, last.close),
        lowerWick: Math.min(last.open, last.close) - last.low,
        range: last.high - last.low
      }
    };
  }

  private static detectPattern(
    last: Candle,
    prev: Candle,
    recent: Candle[]
  ): CandlePattern {
    // Check for engulfing
    if (this.isEngulfing(last, prev)) return 'engulfing';

    // Check for hammer
    if (this.isHammer(last)) return 'hammer';

    // Check for doji
    if (this.isDoji(last)) return 'doji';

    // Check for pin bar
    if (this.isPinBar(last)) return 'pin_bar';

    return 'none';
  }

  private static isEngulfing(last: Candle, prev: Candle): boolean {
    const lastBody = Math.abs(last.close - last.open);
    const prevBody = Math.abs(prev.close - prev.open);

    // Previous candle must have a body
    if (prevBody < 0.0001) return false;

    // Last candle's body must engulf previous
    if (lastBody < prevBody * 1.2) return false;

    // Check direction
    const lastBullish = last.close > last.open;
    const prevBullish = prev.close > prev.open;

    // Bullish engulfing: prev bearish, last bullish, last engulfs
    if (!prevBullish && lastBullish && last.open < prev.close && last.close > prev.open) {
      return true;
    }

    // Bearish engulfing: prev bullish, last bearish, last engulfs
    if (prevBullish && !lastBullish && last.open > prev.close && last.close < prev.open) {
      return true;
    }

    return false;
  }

  private static isHammer(candle: Candle): boolean {
    const body = Math.abs(candle.close - candle.open);
    const range = candle.high - candle.low;
    const lowerWick = Math.min(candle.open, candle.close) - candle.low;
    const upperWick = candle.high - Math.max(candle.open, candle.close);

    if (range < 0.0001) return false;

    // Hammer: long lower wick, small body, little/no upper wick
    if (lowerWick >= body * 2 && lowerWick >= range * 0.6 && upperWick < range * 0.2) {
      return true;
    }

    return false;
  }

  private static isDoji(candle: Candle): boolean {
    const body = Math.abs(candle.close - candle.open);
    const range = candle.high - candle.low;

    if (range < 0.0001) return false;

    // Doji: body is very small relative to range
    return body < range * 0.1;
  }

  private static isPinBar(candle: Candle): boolean {
    const body = Math.abs(candle.close - candle.open);
    const range = candle.high - candle.low;
    const upperWick = candle.high - Math.max(candle.open, candle.close);
    const lowerWick = Math.min(candle.open, candle.close) - candle.low;

    if (range < 0.0001) return false;

    // Pin bar: one wick is very long, body is in opposite third
    const longUpperWick = upperWick >= range * 0.6 && lowerWick < range * 0.2;
    const longLowerWick = lowerWick >= range * 0.6 && upperWick < range * 0.2;

    return longUpperWick || longLowerWick;
  }

  private static isPatternBullish(pattern: CandlePattern, last: Candle, prev: Candle): boolean {
    if (pattern === 'none') return false;

    if (pattern === 'engulfing') {
      return last.close > last.open; // Bullish if last candle is bullish
    }

    if (pattern === 'hammer') {
      return true; // Hammers are generally bullish
    }

    if (pattern === 'pin_bar') {
      const upperWick = last.high - Math.max(last.open, last.close);
      const lowerWick = Math.min(last.open, last.close) - last.low;
      return lowerWick > upperWick; // Bullish if long lower wick
    }

    return false;
  }

  private static determineLocation(last: Candle, candles: Candle[]): string {
    const recent = candles.slice(-20);
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));
    const mid = (recentHigh + recentLow) / 2;

    const currentPrice = last.close;
    const range = recentHigh - recentLow;
    const threshold = range * 0.1;

    if (Math.abs(currentPrice - recentLow) < threshold) return 'at_support';
    if (Math.abs(currentPrice - recentHigh) < threshold) return 'at_resistance';

    if (currentPrice < mid - range * 0.3) return 'near_support';
    if (currentPrice > mid + range * 0.3) return 'near_resistance';

    return 'mid_range';
  }

  private static calculateScore(pattern: CandlePattern, bullish: boolean, location: string): number {
    let score = 0;

    if (pattern === 'none') return 0;

    // Base pattern score
    if (pattern === 'engulfing') score = bullish ? 25 : -25;
    else if (pattern === 'hammer') score = 20;
    else if (pattern === 'pin_bar') score = bullish ? 15 : -15;
    else if (pattern === 'doji') score = 0; // Neutral

    // Location modifier
    if (location === 'at_support' && bullish) score += 10;
    else if (location === 'at_resistance' && !bullish) score -= 10;

    return Math.max(-100, Math.min(100, score));
  }

  private static insufficientData(): CandlestickAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for candlestick analysis'],
      pattern: 'none',
      bullish: false,
      location: 'mid_range',
      details: {}
    };
  }
}

interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
}
