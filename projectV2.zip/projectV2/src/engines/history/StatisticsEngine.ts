// Statistics Engine - Calculates performance metrics
// This layer never changes live signals

import { TradeRecord, SessionStats } from '../../types';

export class StatisticsEngine {
  static calculateWinRate(trades: TradeRecord[]): number {
    const signals = trades.filter(t => t.decision !== 'WAIT');
    if (signals.length === 0) return 0;

    // For binary options simulation, we can only estimate based on confidence
    // Higher confidence trades would have higher "win probability"
    let totalWinProb = 0;

    for (const trade of signals) {
      // Simplified: assume trades with 70%+ confidence "win"
      if (trade.confidence >= 70) totalWinProb += 1;
      else if (trade.confidence >= 60) totalWinProb += 0.7;
      else totalWinProb += 0.5;
    }

    return Math.round((totalWinProb / signals.length) * 100);
  }

  static calculateLossRate(trades: TradeRecord[]): number {
    return 100 - this.calculateWinRate(trades);
  }

  static calculateTradeDistribution(trades: TradeRecord[]): {
    byDecision: { call: number; put: number; wait: number };
    byPair: Record<string, number>;
    byTimeframe: { '5min': number; '15min': number };
    byHour: number[];
    byConfidence: { high: number; medium: number; low: number };
  } {
    const byDecision = {
      call: trades.filter(t => t.decision === 'CALL').length,
      put: trades.filter(t => t.decision === 'PUT').length,
      wait: trades.filter(t => t.decision === 'WAIT').length
    };

    const byPair: Record<string, number> = {};
    for (const trade of trades) {
      byPair[trade.pair] = (byPair[trade.pair] || 0) + 1;
    }

    const byTimeframe = {
      '5min': trades.filter(t => t.timeframe === '5min').length,
      '15min': trades.filter(t => t.timeframe === '15min').length
    };

    const byHour = new Array(24).fill(0);
    for (const trade of trades) {
      const hour = new Date(trade.timestamp).getHours();
      byHour[hour]++;
    }

    const byConfidence = {
      high: trades.filter(t => t.confidence >= 80).length,
      medium: trades.filter(t => t.confidence >= 60 && t.confidence < 80).length,
      low: trades.filter(t => t.confidence < 60).length
    };

    return { byDecision, byPair, byTimeframe, byHour, byConfidence };
  }

  static calculateConfidenceVsOutcome(trades: TradeRecord[]): {
    highConfidenceWins: number;
    highConfidenceTotal: number;
    mediumConfidenceWins: number;
    mediumConfidenceTotal: number;
    lowConfidenceWins: number;
    lowConfidenceTotal: number;
  } {
    const signals = trades.filter(t => t.decision !== 'WAIT');

    const highConf = signals.filter(t => t.confidence >= 80);
    const medConf = signals.filter(t => t.confidence >= 60 && t.confidence < 80);
    const lowConf = signals.filter(t => t.confidence < 60);

    const estimateWins = (trades: TradeRecord[]): number => {
      return trades.reduce((sum, t) => {
        if (t.confidence >= 70) return sum + 1;
        if (t.confidence >= 60) return sum + 0.7;
        return sum + 0.5;
      }, 0);
    };

    return {
      highConfidenceWins: Math.round(estimateWins(highConf)),
      highConfidenceTotal: highConf.length,
      mediumConfidenceWins: Math.round(estimateWins(medConf)),
      mediumConfidenceTotal: medConf.length,
      lowConfidenceWins: Math.round(estimateWins(lowConf)),
      lowConfidenceTotal: lowConf.length
    };
  }

  static calculateBestConditions(trades: TradeRecord[]): {
    bestPairs: string[];
    bestHours: number[];
    bestDecisions: { CALL: boolean; PUT: boolean };
  } {
    const signals = trades.filter(t => t.decision !== 'WAIT');

    // Best pairs by average confidence
    const pairConf: Record<string, { total: number; count: number }> = {};
    for (const trade of signals) {
      if (!pairConf[trade.pair]) pairConf[trade.pair] = { total: 0, count: 0 };
      pairConf[trade.pair].total += trade.confidence;
      pairConf[trade.pair].count++;
    }

    const pairAvgs = Object.entries(pairConf)
      .map(([pair, data]) => ({ pair, avg: data.total / data.count }))
      .sort((a, b) => b.avg - a.avg);

    const bestPairs = pairAvgs.slice(0, 3).map(p => p.pair);

    // Best hours by signal count
    const hourCounts = new Array(24).fill(0);
    for (const trade of signals) {
      const hour = new Date(trade.timestamp).getHours();
      hourCounts[hour]++;
    }

    const bestHours = hourCounts
      .map((count, hour) => ({ hour, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 4)
      .map(h => h.hour);

    // Best decisions
    const callAvg = signals.filter(t => t.decision === 'CALL').reduce((s, t) => s + t.confidence, 0) /
                    (signals.filter(t => t.decision === 'CALL').length || 1);
    const putAvg = signals.filter(t => t.decision === 'PUT').reduce((s, t) => s + t.confidence, 0) /
                   (signals.filter(t => t.decision === 'PUT').length || 1);

    const bestDecisions = {
      CALL: callAvg >= putAvg,
      PUT: putAvg > callAvg
    };

    return { bestPairs, bestHours, bestDecisions };
  }

  static calculateHourlyPerformance(trades: TradeRecord[]): {
    hour: number;
    total: number;
    calls: number;
    puts: number;
    avgConfidence: number;
  }[] {
    const hourlyData: Map<number, { total: number; calls: number; puts: number; confidenceSum: number }> = new Map();

    for (const trade of trades.filter(t => t.decision !== 'WAIT')) {
      const hour = new Date(trade.timestamp).getHours();
      const existing = hourlyData.get(hour) || { total: 0, calls: 0, puts: 0, confidenceSum: 0 };
      existing.total++;
      existing.confidenceSum += trade.confidence;
      if (trade.decision === 'CALL') existing.calls++;
      if (trade.decision === 'PUT') existing.puts++;
      hourlyData.set(hour, existing);
    }

    const result: { hour: number; total: number; calls: number; puts: number; avgConfidence: number }[] = [];

    for (let hour = 0; hour < 24; hour++) {
      const data = hourlyData.get(hour);
      if (data) {
        result.push({
          hour,
          total: data.total,
          calls: data.calls,
          puts: data.puts,
          avgConfidence: Math.round(data.confidenceSum / data.total)
        });
      }
    }

    return result.sort((a, b) => a.hour - b.hour);
  }
}
