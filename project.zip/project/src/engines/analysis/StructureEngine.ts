// Structure Engine - Determines market structure (HH, HL, LH, LL, BOS, CHoCH)
// NEVER generates CALL/PUT signals

import { MarketSnapshot, StructureAnalysis, StructureType } from '../../types';

export class StructureEngine {
  private static readonly SWING_LOOKBACK = 5;

  static analyze(snapshot: MarketSnapshot): StructureAnalysis {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const highs = candles.map(c => c.high);
    const lows = candles.map(c => c.low);
    const closes = candles.map(c => c.close);

    // Find swing points
    const swingHighs = this.findSwingHighs(highs);
    const swingLows = this.findSwingLows(lows);

    // Determine structure
    const structure = this.determineStructure(swingHighs, swingLows, closes);

    // Check for break of structure
    const breaksStructure = this.checkBreakOfStructure(candles, structure);

    // Count structure types
    const counts = this.countStructureTypes(swingHighs, swingLows);

    // Calculate score
    const score = this.calculateScore(structure, breaksStructure, counts);

    const pass = structure !== 'none' && Math.abs(score) >= 20;

    const reasons: string[] = [];
    if (structure === 'HH' || structure === 'HL') {
      reasons.push('Bullish market structure - higher highs/higher lows');
    } else if (structure === 'LH' || structure === 'LL') {
      reasons.push('Bearish market structure - lower highs/lower lows');
    }

    if (breaksStructure) {
      reasons.push('Break of structure detected - potential trend continuation');
    }

    if (counts.higherHighs > counts.lowerHighs) {
      reasons.push(`Higher highs count: ${counts.higherHighs}`);
    } else if (counts.lowerHighs > counts.higherHighs) {
      reasons.push(`Lower highs count: ${counts.lowerHighs}`);
    }

    return {
      score,
      pass,
      reasons,
      pattern: structure,
      breaksStructure,
      ...counts,
      details: {
        swingHighs: swingHighs.slice(-3),
        swingLows: swingLows.slice(-3),
        trendQuality: this.calculateTrendQuality(counts)
      }
    };
  }

  private static findSwingHighs(highs: number[]): number[] {
    const pivots: number[] = [];
    const lb = this.SWING_LOOKBACK;

    for (let i = lb; i < highs.length - lb; i++) {
      let isSwingHigh = true;
      for (let j = 1; j <= lb; j++) {
        if (highs[i] <= highs[i - j] || highs[i] <= highs[i + j]) {
          isSwingHigh = false;
          break;
        }
      }
      if (isSwingHigh) pivots.push(highs[i]);
    }

    return pivots;
  }

  private static findSwingLows(lows: number[]): number[] {
    const pivots: number[] = [];
    const lb = this.SWING_LOOKBACK;

    for (let i = lb; i < lows.length - lb; i++) {
      let isSwingLow = true;
      for (let j = 1; j <= lb; j++) {
        if (lows[i] >= lows[i - j] || lows[i] >= lows[i + j]) {
          isSwingLow = false;
          break;
        }
      }
      if (isSwingLow) pivots.push(lows[i]);
    }

    return pivots;
  }

  private static determineStructure(
    swingHighs: number[],
    swingLows: number[],
    closes: number[]
  ): StructureType {
    if (swingHighs.length < 2 || swingLows.length < 2) return 'none';

    const lastHigh = swingHighs[swingHighs.length - 1];
    const prevHigh = swingHighs[swingHighs.length - 2];
    const lastLow = swingLows[swingLows.length - 1];
    const prevLow = swingLows[swingLows.length - 2];

    // Check for higher highs
    if (lastHigh > prevHigh) {
      if (lastLow > prevLow) return 'HH'; // Higher High confirmed with Higher Low
      return 'HL'; // Higher Low forming
    }

    // Check for lower highs
    if (lastHigh < prevHigh) {
      if (lastLow < prevLow) return 'LL'; // Lower Low confirmed
      return 'LH'; // Lower High forming
    }

    return 'none';
  }

  private static checkBreakOfStructure(
    candles: Candle[],
    currentStructure: StructureType
  ): boolean {
    if (currentStructure === 'none') return false;

    const lastCandle = candles[candles.length - 1];
    const prevCandle = candles[candles.length - 2];

    // Check for significant break
    const bodySize = Math.abs(lastCandle.close - lastCandle.open);
    const avgBody = candles.slice(-10).reduce((sum, c) =>
      sum + Math.abs(c.close - c.open), 0) / 10;

    // Break of structure if body is 1.5x average and closes beyond previous
    if (bodySize > avgBody * 1.5) {
      if (currentStructure === 'HH' || currentStructure === 'HL') {
        return lastCandle.close > prevCandle.high;
      } else {
        return lastCandle.close < prevCandle.low;
      }
    }

    return false;
  }

  private static countStructureTypes(
    swingHighs: number[],
    swingLows: number[]
  ): { higherHighs: number; higherLows: number; lowerHighs: number; lowerLows: number } {
    let higherHighs = 0;
    let lowerHighs = 0;
    let higherLows = 0;
    let lowerLows = 0;

    for (let i = 1; i < swingHighs.length; i++) {
      if (swingHighs[i] > swingHighs[i - 1]) higherHighs++;
      else lowerHighs++;
    }

    for (let i = 1; i < swingLows.length; i++) {
      if (swingLows[i] > swingLows[i - 1]) higherLows++;
      else lowerLows++;
    }

    return { higherHighs, higherLows, lowerHighs, lowerLows };
  }

  private static calculateScore(
    structure: StructureType,
    breaksStructure: boolean,
    counts: { higherHighs: number; higherLows: number; lowerHighs: number; lowerLows: number }
  ): number {
    let score = 0;

    // Structure contribution
    if (structure === 'HH') score += 30;
    else if (structure === 'HL') score += 25;
    else if (structure === 'LH') score -= 25;
    else if (structure === 'LL') score -= 30;

    // Break of structure bonus
    if (breaksStructure) {
      score += structure === 'HH' || structure === 'HL' ? 15 : -15;
    }

    // Count imbalance contribution
    const bullishCount = counts.higherHighs + counts.higherLows;
    const bearishCount = counts.lowerHighs + counts.lowerLows;

    if (bullishCount > bearishCount) score += (bullishCount - bearishCount) * 3;
    else if (bearishCount > bullishCount) score -= (bearishCount - bullishCount) * 3;

    return Math.max(-100, Math.min(100, score));
  }

  private static calculateTrendQuality(counts: {
    higherHighs: number;
    higherLows: number;
    lowerHighs: number;
    lowerLows: number;
  }): number {
    const bullish = counts.higherHighs + counts.higherLows;
    const bearish = counts.lowerHighs + counts.lowerLows;
    const total = bullish + bearish;

    if (total === 0) return 50;

    return Math.round((bullish / total) * 100);
  }

  private static insufficientData(): StructureAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for structure analysis'],
      pattern: 'none',
      breaksStructure: false,
      higherHighs: 0,
      higherLows: 0,
      lowerHighs: 0,
      lowerLows: 0,
      details: {}
    };
  }
}

interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
}
