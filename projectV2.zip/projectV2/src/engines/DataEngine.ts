// Data Engine - Responsible only for acquiring and validating market data
// No analysis. No decisions.

import { Candle, MarketSnapshot, Timeframe } from '../types';

export interface DataEngineConfig {
  apiKey?: string;
  demoMode?: boolean;
}

export class DataEngine {
  private apiKey: string | null = null;
  private demoMode: boolean = false;
  private cache: Map<string, { data: Candle[]; timestamp: number }> = new Map();
  private readonly CACHE_TTL = 30000; // 30 seconds

  private static readonly FOREX_PAIRS = ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'EUR/GBP'];
  private static readonly CRYPTO_PAIRS = ['BTC/USD', 'ETH/USD', 'BNB/USD', 'XRP/USD', 'SOL/USD'];

  // Seed prices for demo mode
  private static readonly SEED_PRICES: Record<string, number> = {
    'EUR/USD': 1.0842, 'GBP/USD': 1.2731, 'USD/JPY': 149.82, 'AUD/USD': 0.6521,
    'USD/CAD': 1.3614, 'EUR/GBP': 0.8521, 'BTC/USD': 67430, 'ETH/USD': 3512,
    'BNB/USD': 594, 'XRP/USD': 0.5831, 'SOL/USD': 172.4
  };

  private demoPrices: Record<string, number> = { ...DataEngine.SEED_PRICES };

  constructor(config?: DataEngineConfig) {
    if (config?.apiKey) {
      this.apiKey = config.apiKey;
    }
    if (config?.demoMode) {
      this.demoMode = true;
    }
  }

  setApiKey(key: string): void {
    this.apiKey = key;
    this.demoMode = false;
  }

  enableDemoMode(): void {
    this.demoMode = true;
    this.demoPrices = { ...DataEngine.SEED_PRICES };
  }

  isDemoMode(): boolean {
    return this.demoMode;
  }

  // Fetch candles from API or generate demo data
  async fetchCandles(pair: string, timeframe: Timeframe, count: number = 60): Promise<Candle[]> {
    if (this.demoMode) {
      return this.generateDemoCandles(pair, timeframe, count);
    }

    // Check cache first
    const cacheKey = `${pair}-${timeframe}`;
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.CACHE_TTL) {
      return cached.data;
    }

    if (!this.apiKey) {
      throw new Error('API key required for live data');
    }

    const interval = timeframe === '5min' ? '5min' : '15min';
    const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(pair)}&interval=${interval}&outputsize=${count}&apikey=${this.apiKey}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      if (data.status === 'error') {
        throw new Error(data.message || 'API error');
      }

      if (!data.values || data.values.length === 0) {
        throw new Error('No data returned');
      }

      // Reverse to get oldest-first order
      const candles = data.values.reverse().map((v: {
        datetime: string;
        open: string;
        high: string;
        low: string;
        close: string;
        volume: string;
      }) => ({
        open: parseFloat(v.open),
        high: parseFloat(v.high),
        low: parseFloat(v.low),
        close: parseFloat(v.close),
        volume: parseFloat(v.volume) || 0,
        timestamp: new Date(v.datetime.replace(' ', 'T')).getTime()
      }));

      // Validate candles
      const validatedCandles = this.validateCandles(candles);

      // Cache the result
      this.cache.set(cacheKey, { data: validatedCandles, timestamp: Date.now() });

      // Update demo price for fallback
      this.demoPrices[pair] = validatedCandles[validatedCandles.length - 1].close;

      return validatedCandles;
    } catch (error) {
      console.error('Data fetch error:', error);
      // Fallback to demo data
      return this.generateDemoCandles(pair, timeframe, count);
    }
  }

  // Fetch only current price (lighter API call)
  async fetchPrice(pair: string): Promise<number> {
    if (this.demoMode) {
      return this.walkDemoPrice(pair);
    }

    if (!this.apiKey) {
      return this.demoPrices[pair] || DataEngine.SEED_PRICES[pair] || 1;
    }

    try {
      const url = `https://api.twelvedata.com/price?symbol=${encodeURIComponent(pair)}&apikey=${this.apiKey}`;
      const response = await fetch(url);
      const data = await response.json();

      if (data.price) {
        const price = parseFloat(data.price);
        this.demoPrices[pair] = price;
        return price;
      }
      throw new Error('No price in response');
    } catch {
      return this.walkDemoPrice(pair);
    }
  }

  // Create market snapshot
  createSnapshot(pair: string, timeframe: Timeframe, candles: Candle[]): MarketSnapshot {
    return {
      pair,
      timeframe,
      candles,
      currentPrice: candles[candles.length - 1]?.close || 0,
      timestamp: Date.now(),
      latestCandleTimestamp: candles[candles.length - 1]?.timestamp || Date.now()
    };
  }

  // Validate candles - check for data integrity
  private validateCandles(candles: Candle[]): Candle[] {
    return candles.filter(candle => {
      // Check for valid OHLC relationship
      if (candle.high < candle.low) return false;
      if (candle.open > candle.high || candle.open < candle.low) return false;
      if (candle.close > candle.high || candle.close < candle.low) return false;

      // Check for zero/negative prices
      if (candle.open <= 0 || candle.high <= 0 || candle.low <= 0 || candle.close <= 0) {
        return false;
      }

      // Check for reasonable price movement (not > 50% in one candle)
      const range = candle.high - candle.low;
      const mid = (candle.high + candle.low) / 2;
      if (range / mid > 0.5) return false;

      return true;
    });
  }

  // Normalize data - adjust for splits, dividends, etc. (placeholder)
  normalizeData(candles: Candle[]): Candle[] {
    // For forex/crypto, splits don't apply
    // This could be extended for equities
    return candles;
  }

  // Generate demo candles
  private generateDemoCandles(pair: string, timeframe: Timeframe, count: number): Candle[] {
    const candles: Candle[] = [];
    const seed = this.demoPrices[pair] || DataEngine.SEED_PRICES[pair] || 1;
    const isCrypto = DataEngine.CRYPTO_PAIRS.includes(pair);
    const volatility = isCrypto ? 0.005 : 0.00035;
    const tfMinutes = timeframe === '5min' ? 5 : 15;

    let price = seed * (0.992 + Math.random() * 0.016);
    const now = Date.now();

    for (let i = 0; i < count; i++) {
      const open = price;
      const change = (Math.random() - 0.495) * volatility * price;
      price = Math.max(price * 0.001, price + change);

      const high = Math.max(open, price) * (1 + Math.random() * volatility * 0.5);
      const low = Math.min(open, price) * (1 - Math.random() * volatility * 0.5);
      const volume = isCrypto ? 1000000 + Math.random() * 5000000 : 1000 + Math.random() * 5000;

      candles.push({
        open: +open.toFixed(isCrypto ? 2 : 5),
        high: +high.toFixed(isCrypto ? 2 : 5),
        low: +low.toFixed(isCrypto ? 2 : 5),
        close: +price.toFixed(isCrypto ? 2 : 5),
        volume: +volume.toFixed(2),
        timestamp: now - (count - i) * tfMinutes * 60 * 1000
      });
    }

    // Update current demo price
    this.demoPrices[pair] = candles[candles.length - 1].close;

    return candles;
  }

  // Walk demo price for real-time updates
  private walkDemoPrice(pair: string): number {
    const isCrypto = DataEngine.CRYPTO_PAIRS.includes(pair);
    const volatility = isCrypto ? 0.003 : 0.00022;

    const current = this.demoPrices[pair] || DataEngine.SEED_PRICES[pair] || 1;
    const change = (Math.random() - 0.495) * volatility * current;
    const newPrice = Math.max(0.0001, current + change);

    this.demoPrices[pair] = +newPrice.toFixed(isCrypto ? 2 : 5);
    return this.demoPrices[pair];
  }

  // Get all available pairs
  static getAvailablePairs(): { forex: string[]; crypto: string[] } {
    return {
      forex: [...DataEngine.FOREX_PAIRS],
      crypto: [...DataEngine.CRYPTO_PAIRS]
    };
  }

  // Get current demo prices
  getDemoPrices(): Record<string, number> {
    return { ...this.demoPrices };
  }

  // Get the polling interval used by the refresh timer
  getRefreshIntervalSeconds(): number {
    return Math.round(this.CACHE_TTL / 1000);
  }

  // Clear cache
  clearCache(): void {
    this.cache.clear();
  }

  // Test API key validity
  static async testApiKey(key: string): Promise<{ ok: boolean; message: string }> {
    try {
      const url = `https://api.twelvedata.com/price?symbol=EUR/USD&apikey=${key}`;
      const response = await fetch(url);
      const data = await response.json();

      if (data.code === 401) {
        return { ok: false, message: 'Invalid API key' };
      }
      if (data.code === 429) {
        return { ok: false, message: 'Rate limit reached - wait a minute and try again' };
      }
      if (data.price) {
        return { ok: true, message: 'API key valid' };
      }
      return { ok: false, message: 'Unexpected response from API' };
    } catch (error) {
      return { ok: false, message: 'Network error - check your connection' };
    }
  }
}
