// Decision Engine - ONLY engine that may produce CALL, PUT, or WAIT
// Has absolute authority over the final decision
// PHILOSOPHY: "If I could take only one trade today, would I take this one?"
// If uncertain -> WAIT

import { MarketSnapshot, Decision, DecisionOutput, EngineResult, RiskAssessment, ConfluenceResult, ValidationResult } from '../../types';

export class DecisionEngine {
  static decide(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>,
    risk: RiskAssessment,
    confluence: ConfluenceResult,
    validation: ValidationResult
  ): DecisionOutput {
    const timestamp = Date.now();

    // Validator has absolute veto power
    if (!validation.approved) {
      return this.createWaitDecision(
        validation.vetoes,
        risk,
        confluence,
        validation,
        timestamp,
        engineResults
      );
    }

    // Calculate trade score and confidence independently
    const tradeScore = this.calculateTradeScore(engineResults, risk, confluence);
    const confidence = this.calculateConfidence(confluence, validation, risk);

    // Determine decision with conservative thresholds
    const decision = this.determineDecision(engineResults, confluence, tradeScore, confidence, risk);

    // Generate reasons
    const reasons = this.generateReasons(decision, engineResults, confluence, validation, risk);

    if (decision === 'WAIT') {
      return this.createWaitDecision(
        reasons,
        risk,
        confluence,
        validation,
        timestamp,
        engineResults,
        tradeScore,
        confidence
      );
    }

    return {
      decision,
      tradeScore,
      confidence,
      reasons,
      risk,
      confluence,
      validation,
      timestamp,
    };
  }

  private static determineDecision(
    engineResults: Record<string, EngineResult>,
    confluence: ConfluenceResult,
    tradeScore: number,
    confidence: number,
    risk: RiskAssessment
  ): Decision {
    // HIGH CONFIDENCE THRESHOLD - must be 65%+
    if (confidence < 65) return 'WAIT';

    // HIGH TRADE SCORE THRESHOLD - must be 55+
    if (Math.abs(tradeScore) < 55) return 'WAIT';

    // Risk must be LOW only - moderate gets WAIT
    if (risk.recommendation !== 'low') return 'WAIT';

    // Need CLEAR directional bias
    const directionBias = confluence.bullishEngines - confluence.bearishEngines;
    const totalEngines = confluence.bullishEngines + confluence.bearishEngines + confluence.neutralEngines;
    const directionRatio = totalEngines > 0 ? directionBias / totalEngines : 0;

    // Need STRONG directional agreement (at least 40% bias)
    if (Math.abs(directionRatio) < 0.4) return 'WAIT';

    // Additional check: most engines must agree on direction
    const maxDirection = Math.max(confluence.bullishEngines, confluence.bearishEngines);
    const directionPercent = totalEngines > 0 ? maxDirection / totalEngines : 0;
    if (directionPercent < 0.5) return 'WAIT';

    // Determine CALL or PUT
    if (directionRatio > 0.4 && tradeScore >= 55 && confidence >= 65) {
      return 'CALL';
    }

    if (directionRatio < -0.4 && tradeScore <= -55 && confidence >= 65) {
      return 'PUT';
    }

    return 'WAIT';
  }

  private static calculateTradeScore(
    engineResults: Record<string, EngineResult>,
    risk: RiskAssessment,
    confluence: ConfluenceResult
  ): number {
    // Trade Score measures setup quality independently
    let totalScore = 0;
    let weightSum = 0;

    // Weighted by engine importance
    const weights: Record<string, number> = {
      trend: 4,           // Most important
      momentum: 3,         // Key confirmation
      structure: 3,        // Market context
      regime: 2.5,         // Trend/sideways
      volatility: 2,       // Risk context
      supportResistance: 2, // Entry level
      liquidity: 1.5,      // Stop hunt risk
      pullback: 2,          // Entry timing
      breakout: 1.5,       // Momentum confirmation
      candlestick: 1,       // Entry trigger
      trendAge: 1.5,        // Trend freshness
      trendSlope: 1,        // Trend acceleration
      stability: 1,         // Market consistency
      retest: 1,            // Level confirmation
      session: 0.5          // Session timing
    };

    for (const [name, result] of Object.entries(engineResults)) {
      const weight = weights[name] || 1;
      totalScore += result.score * weight;
      weightSum += weight;
    }

    const avgScore = weightSum > 0 ? totalScore / weightSum : 0;

    // Scale to 0-100 (setup quality, not direction)
    return Math.round(Math.max(0, Math.min(100, (avgScore + 100) / 2)));
  }

  private static calculateConfidence(
    confluence: ConfluenceResult,
    validation: ValidationResult,
    risk: RiskAssessment
  ): number {
    // Confidence measures certainty in the decision
    let confidence = 50;

    // Confluence contribution (max 25 points)
    confidence += (confluence.agreement / 100) * 25;

    // Validation contribution (max 15 points)
    const validationRate = validation.mandatoryChecksPassed / validation.mandatoryChecksTotal;
    confidence += validationRate * 15;

    // Risk contribution
    if (risk.recommendation === 'low') confidence += 10;
    else if (risk.recommendation === 'moderate') confidence += 3;
    else confidence -= 15;

    // Key alignments bonus
    confidence += Math.min(8, confluence.keyAlignments.length * 2);

    // Contradictions penalty
    confidence -= confluence.contradictions.length * 10;

    // Warnings penalty
    confidence -= validation.warnings.length * 3;

    return Math.round(Math.max(0, Math.min(100, confidence)));
  }

  private static generateReasons(
    decision: Decision,
    engineResults: Record<string, EngineResult>,
    confluence: ConfluenceResult,
    validation: ValidationResult,
    risk: RiskAssessment
  ): string[] {
    const reasons: string[] = [];

    if (decision === 'CALL' || decision === 'PUT') {
      // List positive factors
      const strongEngines = Object.entries(engineResults)
        .filter(([_, r]) => Math.abs(r.score) >= 20)
        .sort((a, b) => Math.abs(b[1].score) - Math.abs(a[1].score))
        .slice(0, 3);

      for (const [name, result] of strongEngines) {
        if (result.reasons.length > 0) {
          reasons.push(...result.reasons.slice(0, 1));
        }
      }

      if (confluence.keyAlignments.length > 0) {
        reasons.push(...confluence.keyAlignments.slice(0, 2));
      }

      reasons.push(`Risk: ${risk.recommendation.toUpperCase()}`);
      reasons.push(`${validation.mandatoryChecksPassed}/${validation.mandatoryChecksTotal} checks passed`);
    } else {
      // Explain why WAIT
      if (validation.vetoes.length > 0) {
        reasons.push(...validation.vetoes.slice(0, 3));
      }

      if (risk.recommendation !== 'low') {
        reasons.push(`Risk level: ${risk.recommendation}`);
      }

      if (confluence.agreement < 55) {
        reasons.push(`Low confluence: ${confluence.agreement}%`);
      }
    }

    return reasons;
  }

  private static createWaitDecision(
    reasons: string[],
    risk: RiskAssessment,
    confluence: ConfluenceResult,
    validation: ValidationResult,
    timestamp: number,
    engineResults: Record<string, EngineResult>,
    tradeScore?: number,
    confidence?: number
  ): DecisionOutput {
    return {
      decision: 'WAIT',
      tradeScore: tradeScore ?? this.calculateTradeScore(engineResults, risk, confluence),
      confidence: confidence ?? this.calculateConfidence(confluence, validation, risk),
      reasons,
      risk,
      confluence,
      validation,
      timestamp,
    };
  }
}
