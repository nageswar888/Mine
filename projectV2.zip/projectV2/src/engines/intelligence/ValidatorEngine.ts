// Validator Engine - Has absolute veto power
// If any mandatory condition fails, immediately rejects the setup
// NEVER generates CALL/PUT signals
// CONSERVATIVE: Only approve HIGH-QUALITY setups

import { MarketSnapshot, ValidationResult, EngineResult, ConfluenceResult } from '../../types';

export class ValidatorEngine {
  static validate(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>,
    riskAssessment: { totalRisk: number; recommendation: string },
    confluence: ConfluenceResult
  ): ValidationResult {
    const vetoes: string[] = [];
    const warnings: string[] = [];

    // ALL mandatory checks must pass - no exceptions
    // This is the core of the conservative philosophy
    const mandatoryChecks: Array<{ check: boolean; name: string; reason: string }> = [
      {
        check: this.checkTrendStrength(engineResults),
        name: 'Trend Strength',
        reason: 'Weak or no clear trend direction'
      },
      {
        check: this.checkMomentum(engineResults),
        name: 'Momentum',
        reason: 'Momentum is weak or showing divergence'
      },
      {
        check: this.checkMarketRegime(engineResults),
        name: 'Market Regime',
        reason: 'Market is ranging or transitioning'
      },
      {
        check: this.checkConfluence(confluence),
        name: 'Confluence',
        reason: 'Insufficient agreement between engines'
      },
      {
        check: this.checkRisk(riskAssessment),
        name: 'Risk Level',
        reason: 'Risk exceeds acceptable threshold'
      },
      {
        check: this.checkVolatility(engineResults),
        name: 'Volatility',
        reason: 'Volatility is extreme or too low'
      },
      {
        check: this.checkStructure(engineResults),
        name: 'Market Structure',
        reason: 'Market structure is unclear'
      },
      {
        check: this.checkFakeout(engineResults),
        name: 'Fakeout Check',
        reason: 'Fake breakout detected'
      }
    ];

    let mandatoryChecksPassed = 0;

    for (const check of mandatoryChecks) {
      if (check.check) {
        mandatoryChecksPassed++;
      } else {
        vetoes.push(check.reason);
      }
    }

    // Non-mandatory warnings
    if (engineResults['session']?.pass === false) {
      warnings.push('Outside optimal trading session');
    }

    if (engineResults['pullback'] && !engineResults['pullback'].pass) {
      warnings.push('Not at optimal pullback entry');
    }

    if (confluence.contradictions.length > 0) {
      warnings.push(`Mixed signals: ${confluence.contradictions.slice(0, 2).join(', ')}`);
    }

    // STRICT: All mandatory checks must pass
    const approved = vetoes.length === 0 && mandatoryChecksPassed === mandatoryChecks.length;

    return {
      approved,
      vetoes,
      warnings,
      mandatoryChecksPassed,
      mandatoryChecksTotal: mandatoryChecks.length
    };
  }

  private static checkTrendStrength(engineResults: Record<string, EngineResult>): boolean {
    const trend = engineResults['trend'];
    if (!trend) return false;

    // Trend must be CLEAR (strong score) and passing
    // Minimum score of ±20 indicates a real trend
    return trend.pass && Math.abs(trend.score) >= 20;
  }

  private static checkMomentum(engineResults: Record<string, EngineResult>): boolean {
    const momentum = engineResults['momentum'];
    if (!momentum) return false;

    // Momentum must be present and NOT showing divergence
    // Divergence often precedes reversals - avoid
    const hasDivergence = momentum.details?.divergence === true;
    return momentum.pass && !hasDivergence && Math.abs(momentum.score) >= 15;
  }

  private static checkMarketRegime(engineResults: Record<string, EngineResult>): boolean {
    const regime = engineResults['regime'];
    if (!regime) return false;

    // Must be trending - avoid sideways/consolidation
    const regimeType = regime.details?.regime as string | undefined;
    return regimeType === 'trending';
  }

  private static checkConfluence(confluence: ConfluenceResult): boolean {
    // High confluence required - most engines must agree
    // This ensures we're not trading on conflicting signals
    return confluence.agreement >= 55;
  }

  private static checkRisk(riskAssessment: { totalRisk: number; recommendation: string }): boolean {
    // Only accept LOW or MODERATE risk
    // HIGH or EXTREME risk = immediate veto
    return riskAssessment.recommendation === 'low' ||
           riskAssessment.recommendation === 'moderate';
  }

  private static checkVolatility(engineResults: Record<string, EngineResult>): boolean {
    const volatility = engineResults['volatility'];
    if (!volatility) return false;

    // Must have HEALTHY volatility - not extreme, not too low
    const state = volatility.details?.state as string | undefined;
    return state === 'healthy';
  }

  private static checkStructure(engineResults: Record<string, EngineResult>): boolean {
    const structure = engineResults['structure'];
    if (!structure) return false;

    // Structure must be clear (not 'none')
    const pattern = structure.details?.pattern as string | undefined;
    return pattern !== undefined && pattern !== 'none';
  }

  private static checkFakeout(engineResults: Record<string, EngineResult>): boolean {
    const liquidity = engineResults['liquidity'];
    if (!liquidity) return true;

    // Must not be a fake breakout - these trap traders
    const event = liquidity.details?.event as string | undefined;
    return event !== 'fake_breakout';
  }

  static calculateValidationScore(validation: ValidationResult): number {
    if (!validation.approved) return -100;

    const passRate = validation.mandatoryChecksPassed / validation.mandatoryChecksTotal;
    const warningPenalty = validation.warnings.length * 5;

    return Math.round(passRate * 100 - warningPenalty);
  }
}
