# SignalX Engine Architecture

## What this project does

SignalX is a trading decision workspace built with React, TypeScript, and a layered engine pipeline. The app lets you select a currency pair and timeframe, gathers market data, runs several technical analysis engines, and then produces a decision such as CALL, PUT, or WAIT along with confidence and supporting reasons.

The UI is designed to feel like a live trading cockpit: it shows the current price, session stats, confidence rings, trade history, and the two countdowns that matter most for signal freshness and candle expiry.

## High-level structure

- Frontend: React + TypeScript rendered by Vite
- Core engine pipeline: a sequence of specialized analysis modules
- Data source: Twelve Data integration with a demo fallback mode
- State handling: local UI state plus engine results and session history

## Core layers

### 1. Data layer

The data layer is responsible for fetching candle history, validating it, and exposing the latest market snapshot. In demo mode it can fall back to seeded data so the app still remains usable without a live API key.

### 2. Indicator layer

Indicator modules transform raw candles into usable momentum, trend, volatility, support/resistance, and liquidity features. These values become the input for the higher-level engines.

### 3. Analysis layer

The analysis engines inspect the market through different lenses:

- trend and regime detection
- breakout and pullback logic
- volatility and stability checks
- liquidity and structure interpretation
- session and historical context

Each engine contributes findings that are then handed off to the intelligence layer.

### 4. Intelligence layer

The intelligence layer combines the engine outputs into a final decision. It produces:

- a trade decision (CALL, PUT, WAIT)
- a confidence score
- reasons and rationale
- risk and validation scoring

### 5. UI layer

The main app component coordinates the timers, selection controls, signal display, and toast notifications. It uses the engine results to render the dashboard without a full page reload.

## Timer behavior

The app uses two independent timers in the UI:

1. Timeframe Ends In
   - Counts down to the next candle boundary for the selected timeframe.
   - Uses the last candle timestamp plus the timeframe duration.
   - Prevents the countdown from appearing to double-count or drift.

2. Next Signal Refresh
   - Counts down to the next automated refresh.
   - Starts from the last successful analysis refresh and resets after each cycle.
   - Triggers a fresh analysis only when the refresh window has fully elapsed.

## Why the architecture is split this way

This separation keeps the app easier to reason about:

- data acquisition is isolated from decision-making
- analysis modules can be added or replaced independently
- the UI can remain responsive while the engine pipeline runs in the background
- timer behavior is explicit and not tied to a hard page refresh

## Development notes

The pipeline is designed so the app can run in:

- live mode with real market data
- demo mode with seeded values for testing and presentation

The current implementation favors clarity and reliability over over-engineering, which makes it easier to extend with new indicators or decision logic later.
