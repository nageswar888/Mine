import { EngineResult, TradeRecord, Timeframe, Decision } from '../../types';

export class HistoricalMemoryEngine {
  private tradeStore: Map<string, TradeRecord> = new Map();

  addTrade(trade: TradeRecord): void {
    if (this.tradeStore.has(trade.id)) return;
    this.tradeStore.set(trade.id, trade);
  }

  getAllTrades(): TradeRecord[] {
    return Array.from(this.tradeStore.values()).sort((a, b) => a.timestamp - b.timestamp);
  }

  getSampleSize(pair?: string, timeframe?: Timeframe): number {
    return this.filterTrades(pair, timeframe).length;
  }

  getWinRate(pair?: string, timeframe?: Timeframe): number {
    const trades = this.filterTrades(pair, timeframe).filter(t => t.decision !== 'WAIT');
    if (trades.length === 0) return 0;

    const wins = trades.reduce((count, trade) => {
      if (trade.confidence >= 70) return count + 1;
      if (trade.confidence >= 60) return count + 0.75;
      return count + 0.5;
    }, 0);

    return Math.round((wins / trades.length) * 100);
  }

  getLossRate(pair?: string, timeframe?: Timeframe): number {
    return 100 - this.getWinRate(pair, timeframe);
  }

  lookupByPairAndTimeframe(pair: string, timeframe: Timeframe): TradeRecord[] {
    return this.filterTrades(pair, timeframe);
  }

  getAverageEngineScore(engineName: string): number {
    const trades = this.getAllTrades();
    if (trades.length === 0) return 0;

    const total = trades.reduce((sum, trade) => {
      const score = trade.engineResults[engineName]?.score;
      return sum + (typeof score === 'number' ? score : 0);
    }, 0);

    return Math.round(total / trades.length);
  }

  findSimilarSetups(currentResults: Record<string, EngineResult>, sampleLimit = 20): {
    similarTrades: TradeRecord[];
    similarityScore: number;
  } {
    const currentSignature = this.buildSignature(currentResults);
    const scoredTrades = this.getAllTrades().map((trade) => {
      const similarity = this.calculateSimilarity(currentSignature, trade.engineResults);
      return { trade, similarity };
    });

    scoredTrades.sort((a, b) => b.similarity - a.similarity);
    const similarTrades = scoredTrades.slice(0, sampleLimit).filter(item => item.similarity > 0.35).map(item => item.trade);
    const similarityScore = similarTrades.length > 0
      ? Math.round(scoredTrades[0].similarity * 100)
      : 0;

    return { similarTrades, similarityScore };
  }

  getFingerprint(engineResults: Record<string, EngineResult>): string {
    const keys = ['trend', 'momentum', 'structure', 'volatility', 'regime', 'liquidity'];
    return keys.map((key) => {
      const score = engineResults[key]?.score;
      return `${key}:${typeof score === 'number' ? Math.round(score / 10) * 10 : 0}`;
    }).join('|');
  }

  getReliability(sampleSize: number): number {
    if (sampleSize <= 0) return 0;
    return Math.min(100, Math.round(Math.log10(sampleSize + 1) * 35 + Math.min(sampleSize, 20)));
  }

  private filterTrades(pair?: string, timeframe?: Timeframe): TradeRecord[] {
    return this.getAllTrades().filter((trade) => {
      if (pair && trade.pair !== pair) return false;
      if (timeframe && trade.timeframe !== timeframe) return false;
      return true;
    });
  }

  private buildSignature(engineResults: Record<string, EngineResult>): Record<string, number> {
    const keys = ['trend', 'momentum', 'structure', 'volatility', 'regime', 'liquidity'];
    const signature: Record<string, number> = {};
    for (const key of keys) {
      signature[key] = engineResults[key]?.score || 0;
    }
    return signature;
  }

  private calculateSimilarity(
    currentSignature: Record<string, number>,
    historicalResults: Record<string, EngineResult>
  ): number {
    const keys = Object.keys(currentSignature);
    if (keys.length === 0) return 0;

    let totalDistance = 0;
    let totalWeight = 0;

    for (const key of keys) {
      const currentScore = currentSignature[key] || 0;
      const historicalScore = historicalResults[key]?.score || 0;
      const weight = 1;
      totalDistance += Math.abs(currentScore - historicalScore) * weight;
      totalWeight += weight;
    }

    const maxDistance = totalWeight * 200;
    const normalized = Math.max(0, 1 - totalDistance / maxDistance);
    return normalized;
  }
}
