// Trend Engine - Determines trend direction, strength, and score
// NEVER generates CALL/PUT signals
// ACCURACY FOCUS: Volume confirmation + multi-EMA alignment

import { MarketSnapshot, TrendAnalysis, TrendDirection, Candle } from '../../types';
import { IndicatorEngine } from '../indicators';

export class TrendEngine {
  private static readonly STRONG_TREND_THRESHOLD = 25;
  private static readonly WEAK_TREND_THRESHOLD = 20;

  static analyze(snapshot: MarketSnapshot): TrendAnalysis {
    const { candles } = snapshot;

    if (candles.length < 50) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const volumes = candles.map(c => c.volume);

    const ema20 = IndicatorEngine.ema(closes, 20);
    const ema50 = IndicatorEngine.ema(closes, 50);
    const ema200 = IndicatorEngine.ema(closes, 200);
    const adx = IndicatorEngine.adx(candles);
    const rsi = IndicatorEngine.rsi(closes);

    const lastIdx = candles.length - 1;
    const currentPrice = closes[lastIdx];
    const currentEma20 = ema20[lastIdx] || currentPrice;
    const currentEma50 = ema50[lastIdx] || currentPrice;
    const currentEma200 = ema200[lastIdx] || currentPrice;
    const currentAdx = adx[lastIdx] || 25;
    const currentRsi = rsi[rsi.length - 1] || 50;

    // Determine trend direction with multi-EMA confirmation
    const direction = this.determineDirection(currentPrice, currentEma20, currentEma50, currentEma200);

    // Calculate trend strength with ADX and volume
    const strength = this.calculateStrength(
      currentAdx,
      currentPrice,
      currentEma20,
      currentEma50,
      currentEma200,
      volumes,
      lastIdx
    );

    // Calculate trend age
    const age = this.determineAge(closes, ema20, ema50);

    // Calculate slope (acceleration)
    const slope = this.calculateSlope(ema20, lastIdx);

    // Volume confirmation check
    const volumeConfirm = this.checkVolumeConfirmation(volumes, closes, lastIdx);

    // Calculate score with accuracy emphasis
    const score = this.calculateScore(direction, strength, age, slope, currentRsi, volumeConfirm);

    // STRICT PASS: strong trend + volume confirmation + clear direction
    const pass = strength >= 30 &&
                 direction !== 'neutral' &&
                 Math.abs(score) >= 20 &&
                 volumeConfirm;

    const reasons: string[] = [];
    if (direction === 'bullish') {
      reasons.push('Bullish trend: price above key EMAs');
      if (currentAdx > this.STRONG_TREND_THRESHOLD) {
        reasons.push(`Strong trend (ADX: ${currentAdx.toFixed(1)})`);
      }
    } else if (direction === 'bearish') {
      reasons.push('Bearish trend: price below key EMAs');
      if (currentAdx > this.STRONG_TREND_THRESHOLD) {
        reasons.push(`Strong trend (ADX: ${currentAdx.toFixed(1)})`);
      }
    } else {
      reasons.push('Neutral - no clear trend direction');
    }

    if (volumeConfirm) {
      reasons.push('Volume confirms trend');
    } else {
      reasons.push('⚠ Volume does not confirm trend');
    }

    if (age === 'exhausted') reasons.push('⚠ Trend may be exhausting');
    if (age === 'fresh') reasons.push('Fresh trend established');

    return {
      score,
      pass,
      reasons,
      direction,
      strength,
      slope,
      age,
      details: {
        ema20: currentEma20,
        ema50: currentEma50,
        ema200: currentEma200,
        adx: currentAdx,
        alignment: this.getEmaAlignment(currentPrice, currentEma20, currentEma50, currentEma200),
        volumeConfirm
      }
    };
  }

  private static determineDirection(
    price: number,
    ema20: number,
    ema50: number,
    ema200: number
  ): TrendDirection {
    // Count bullish conditions
    const bullishConditions = [
      price > ema20,
      price > ema50,
      price > ema200,
      ema20 > ema50,
      ema20 > ema200,
      ema50 > ema200
    ];

    const bullishCount = bullishConditions.filter(Boolean).length;

    // Need 5+ conditions for bullish, 1- for bearish
    if (bullishCount >= 5) return 'bullish';
    if (bullishCount <= 1) return 'bearish';
    return 'neutral';
  }

  private static calculateStrength(
    adx: number,
    price: number,
    ema20: number,
    ema50: number,
    ema200: number,
    volumes: number[],
    lastIdx: number
  ): number {
    // ADX contribution (0-40)
    const adxScore = Math.min(40, adx);

    // EMA alignment contribution (0-30)
    const perfectBullish = price > ema20 && ema20 > ema50 && ema50 > ema200;
    const perfectBearish = price < ema20 && ema20 < ema50 && ema50 < ema200;
    const alignmentScore = (perfectBullish || perfectBearish) ? 30 : 10;

    // Price distance from EMAs (0-20)
    const avgEma = (ema20 + ema50 + ema200) / 3;
    const distancePercent = Math.abs(price - avgEma) / avgEma * 100;
    const distanceScore = Math.min(20, distancePercent * 80);

    // Volume trend contribution (0-10)
    const recentVol = volumes.slice(-10).reduce((a, b) => a + b, 0) / 10;
    const olderVol = volumes.slice(-20, -10).reduce((a, b) => a + b, 0) / 10;
    let volumeScore = 0;
    if (olderVol > 0 && recentVol > olderVol * 1.1) {
      volumeScore = 10; // Increasing volume supports trend
    }

    return Math.round(adxScore + alignmentScore + distanceScore + volumeScore);
  }

  private static checkVolumeConfirmation(
    volumes: number[],
    closes: number[],
    lastIdx: number
  ): boolean {
    // Volume should increase in trend direction
    const recentVol = volumes.slice(-5).reduce((a, b) => a + b, 0) / 5;
    const avgVol = volumes.slice(-20).reduce((a, b) => a + b, 0) / 20;

    // Volume should be at least average, preferably higher
    return recentVol >= avgVol * 0.85;
  }

  private static determineAge(
    closes: number[],
    ema20: number[],
    ema50: number[]
  ): 'fresh' | 'mature' | 'exhausted' {
    const lookback = 20;
    const recentCloses = closes.slice(-lookback);
    const recentEma20 = ema20.slice(-lookback);
    const recentEma50 = ema50.slice(-lookback);

    // Count directional candles
    const bullishCount = recentCloses.slice(1).filter((c, i) => c > recentCloses[i]).length;

    // Find EMA crossover timing
    let crossoverDistance = 0;
    for (let i = recentEma20.length - 1; i > 0 && crossoverDistance < 10; i--) {
      const currentDiff = recentEma20[i] - recentEma50[i];
      const prevDiff = recentEma20[i - 1] - recentEma50[i - 1];
      if (currentDiff * prevDiff < 0) {
        crossoverDistance = recentEma20.length - i;
        break;
      }
    }

    // Check for trend exhaustion (many consecutive same-direction candles)
    const last5Direction = closes.slice(-5).map((c, i) => c > closes[closes.length - 6 + i] ? 1 : -1);
    const consecutiveSame = last5Direction.every(d => d === last5Direction[0]);

    if (crossoverDistance <= 3 || (bullishCount >= lookback * 0.75 && !consecutiveSame)) return 'fresh';
    if (crossoverDistance >= 15 || consecutiveSame) return 'exhausted';
    return 'mature';
  }

  private static calculateSlope(ema: number[], idx: number): number {
    if (idx < 5) return 0;

    const current = ema[idx];
    const prev = ema[idx - 5];
    const avgPrice = (current + prev) / 2;

    return avgPrice !== 0 ? ((current - prev) / avgPrice) * 100 : 0;
  }

  private static calculateScore(
    direction: TrendDirection,
    strength: number,
    age: string,
    slope: number,
    rsi: number,
    volumeConfirm: boolean
  ): number {
    let score = 0;

    // Direction contribution
    if (direction === 'bullish') score += 35;
    else if (direction === 'bearish') score -= 35;

    // Strength contribution normalized
    score += (strength - 50) * 0.5;

    // Age contribution
    if (age === 'fresh') score += 15;
    else if (age === 'exhausted') score -= 15;

    // Slope contribution
    score += slope * 3;

    // RSI context (avoid overbought/oversold extremes)
    if (direction === 'bullish' && rsi >= 35 && rsi <= 70) score += 10;
    if (direction === 'bearish' && rsi >= 30 && rsi <= 65) score += 10;
    if (direction === 'bullish' && rsi > 75) score -= 15;
    if (direction === 'bearish' && rsi < 25) score -= 15;

    // Volume confirmation bonus
    if (volumeConfirm) score += 10;
    else score -= 10;

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static getEmaAlignment(
    price: number,
    ema20: number,
    ema50: number,
    ema200: number
  ): string {
    if (price > ema20 && ema20 > ema50 && ema50 > ema200) return 'perfect_bullish';
    if (price < ema20 && ema20 < ema50 && ema50 < ema200) return 'perfect_bearish';
    if (price > ema20 && ema20 > ema50) return 'bullish_alignment';
    if (price < ema20 && ema20 < ema50) return 'bearish_alignment';
    return 'mixed';
  }

  private static insufficientData(): TrendAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for trend analysis'],
      direction: 'neutral',
      strength: 0,
      slope: 0,
      age: 'exhausted',
      details: {}
    };
  }
}
