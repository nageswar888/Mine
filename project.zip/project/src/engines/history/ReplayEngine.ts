import { EnginePipeline } from '../EnginePipeline';
import { Candle, MarketSnapshot, Timeframe, PipelineResult } from '../../types';

export class ReplayEngine {
  static async replay(
    pipeline: EnginePipeline,
    pair: string,
    timeframe: Timeframe,
    candles: Candle[]
  ): Promise<PipelineResult[]> {
    const results: PipelineResult[] = [];
    const minimum = 60;

    for (let i = minimum; i <= candles.length; i++) {
      const slice = candles.slice(0, i);
      const snapshot: MarketSnapshot = pipeline.getDataEngine().createSnapshot(pair, timeframe, slice);
      const result = await pipeline.executeSnapshot(snapshot);
      results.push(result);
    }

    return results;
  }
}
