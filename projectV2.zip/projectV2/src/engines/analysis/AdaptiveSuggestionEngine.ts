import { AdaptiveSuggestionAnalysis, EngineResult } from '../../types';

export class AdaptiveSuggestionEngine {
  static analyze(engineResults: Record<string, EngineResult>): AdaptiveSuggestionAnalysis {
    const suggestions: string[] = [];
    const trend = engineResults['trend'];
    const momentum = engineResults['momentum'];
    const session = engineResults['session'];
    const validation = engineResults['validation'];

    if (trend && trend.score < 20) {
      suggestions.push('Increase trend threshold - weak trend detected');
    }

    if (momentum && momentum.score < 15) {
      suggestions.push('Reject low momentum setups');
    }

    if (session && !session.pass) {
      suggestions.push('Ignore weak session conditions');
    }

    const validationWarnings = (validation as { warnings?: string[] } | undefined)?.warnings ?? [];
    if (validationWarnings.length > 0) {
      suggestions.push('Tighten validator checks for edge cases');
    }

    if (suggestions.length === 0) {
      suggestions.push('No adjustments recommended - current rules are holding');
    }

    return {
      score: 0,
      pass: true,
      reasons: suggestions,
      suggestions,
      details: {
        trendScore: trend?.score || 0,
        momentumScore: momentum?.score || 0,
        sessionPass: session?.pass || false
      }
    };
  }
}
