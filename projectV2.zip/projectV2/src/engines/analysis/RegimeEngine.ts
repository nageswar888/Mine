// Market Regime Engine - Determines market regime (trending, sideways, consolidation, transition)
// NEVER generates CALL/PUT signals

import { MarketSnapshot, RegimeAnalysis, MarketRegime } from '../../types';
import { IndicatorEngine } from '../indicators';

export class RegimeEngine {
  static analyze(snapshot: MarketSnapshot): RegimeAnalysis {
    const { candles } = snapshot;

    if (candles.length < 50) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const adx = IndicatorEngine.adx(candles);
    const atr = IndicatorEngine.atr(candles);

    // Calculate trending vs sideways scores
    const trendingScore = this.calculateTrendingScore(candles, adx);
    const sidewaysScore = this.calculateSidewaysScore(closes);

    // Determine regime
    const regime = this.determineRegime(trendingScore, sidewaysScore);

    // Calculate score
    const score = this.calculateScore(regime, trendingScore, sidewaysScore);

    const pass = regime === 'trending' || (regime === 'transition' && trendingScore > 40);

    const reasons: string[] = [];
    if (regime === 'trending') {
      reasons.push('Market is trending - favorable for directional trades');
    } else if (regime === 'sideways') {
      reasons.push('⚠ Market is ranging - avoid trend-following strategies');
    } else if (regime === 'consolidation') {
      reasons.push('Market is consolidating - watch for breakout');
    } else if (regime === 'transition') {
      reasons.push('Market regime transitioning - exercise caution');
    }

    return {
      score,
      pass,
      reasons,
      regime,
      trendingScore,
      sidewaysScore,
      details: {
        adx: adx[candles.length - 1] || 25,
        rangeboundPercentage: sidewaysScore
      }
    };
  }

  private static calculateTrendingScore(candles: Candle[], adx: number[]): number {
    const lastIdx = candles.length - 1;
    const currentAdx = adx[lastIdx] || 25;

    // ADX trending contribution (0-50)
    const adxScore = Math.min(50, currentAdx * 1.5);

    // Price displacement contribution
    const closes = candles.map(c => c.close);
    const recentHigh = Math.max(...closes.slice(-20));
    const recentLow = Math.min(...closes.slice(-20));
    const displacement = ((recentHigh - recentLow) / recentLow) * 100;

    // Displacement score (0-50)
    const displacementScore = Math.min(50, displacement * 5);

    return Math.round(adxScore + displacementScore);
  }

  private static calculateSidewaysScore(closes: number[]): number {
    // Calculate how much price stays within a range
    const recent = closes.slice(-20);
    const avg = recent.reduce((a, b) => a + b, 0) / recent.length;

    // Calculate average deviation from mean
    const deviations = recent.map(c => Math.abs(c - avg) / avg);
    const avgDeviation = deviations.reduce((a, b) => a + b, 0) / deviations.length;

    // Low deviation = high sideways score (inverse relationship)
    // If avgDeviation is 0.5% (0.005), that's rangebound
    const sidewaysScore = Math.max(0, 100 - avgDeviation * 5000);

    return Math.round(sidewaysScore);
  }

  private static determineRegime(trendingScore: number, sidewaysScore: number): MarketRegime {
    if (trendingScore > 60 && sidewaysScore < 40) return 'trending';
    if (sidewaysScore > 60 && trendingScore < 40) return 'sideways';
    if (sidewaysScore > 50 && sidewaysScore < 70) return 'consolidation';
    return 'transition';
  }

  private static calculateScore(
    regime: MarketRegime,
    trendingScore: number,
    sidewaysScore: number
  ): number {
    let score = 0;

    if (regime === 'trending') {
      score = Math.round(trendingScore * 0.8);
    } else if (regime === 'sideways') {
      score = -30; // Sideways markets are unfavorable for trend trades
    } else if (regime === 'consolidation') {
      score = 5; // Consolidation is somewhat neutral
    } else if (regime === 'transition') {
      score = -10; // Transitions are uncertain
    }

    return Math.max(-100, Math.min(100, score));
  }

  private static insufficientData(): RegimeAnalysis {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for regime analysis'],
      regime: 'transition',
      trendingScore: 50,
      sidewaysScore: 50,
      details: {}
    };
  }
}

interface Candle {
  close: number;
}
