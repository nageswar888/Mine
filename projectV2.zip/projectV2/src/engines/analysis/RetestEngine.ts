// Retest Engine - Confirms post-breakout retests
// NEVER generates CALL/PUT signals

import { MarketSnapshot, EngineResult } from '../../types';

export class RetestEngine {
  private static readonly LOOKBACK = 15;
  private static readonly NEAR_THRESHOLD = 0.005; // 0.5% from level

  static analyze(snapshot: MarketSnapshot): EngineResult {
    const { candles } = snapshot;

    if (candles.length < 25) {
      return this.insufficientData();
    }

    const last = candles[candles.length - 1];

    // Find recent significant level (breakout level)
    const { level, direction } = this.findRecentBreakout(candles);

    if (!level) {
      return {
        score: 0,
        pass: false,
        reasons: ['No recent breakout level detected for retest'],
        details: {}
      };
    }

    // Check for retest
    const retestDirection = direction === 'none' ? 'up' : direction;
    const retestState = this.checkRetest(last, level, retestDirection);

    // Check if retest is successful (holds as support/resistance)
    const successful = this.isRetestSuccessful(last, level, retestDirection);

    // Calculate score
    const score = this.calculateScore(retestState, successful, retestDirection);

    const pass = retestState.nearLevel;

    const reasons: string[] = [];
    if (retestState.nearLevel) {
      if (successful) {
        reasons.push(`Successful retest of ${direction === 'up' ? 'support' : 'resistance'} level`);
      } else {
        reasons.push('Price near breakout level - checking for retest');
      }
    } else {
      reasons.push('Price away from breakout level');
    }

    return {
      score,
      pass,
      reasons,
      details: {
        level,
        direction,
        distance: retestState.distanceFromLevel,
        touches: retestState.touches,
        successful
      }
    };
  }

  private static findRecentBreakout(candles: Candle[]): {
    level: number | null;
    direction: 'up' | 'down' | 'none';
  } {
    const recent = candles.slice(-10);
    const closes = recent.map(c => c.close);
    const highs = recent.map(c => c.high);
    const lows = recent.map(c => c.low);

    // Find recent swing high/low as breakout level
    const swingHigh = Math.max(...highs.slice(0, -2));
    const swingLow = Math.min(...lows.slice(0, -2));
    const currentPrice = closes[closes.length - 1];

    // Check if we broke above swing high
    const lastHigh = highs[highs.length - 1];
    if (lastHigh > swingHigh && currentPrice > swingHigh) {
      return { level: swingHigh, direction: 'up' };
    }

    // Check if we broke below swing low
    const lastLow = lows[lows.length - 1];
    if (lastLow < swingLow && currentPrice < swingLow) {
      return { level: swingLow, direction: 'down' };
    }

    return { level: null, direction: 'none' };
  }

  private static checkRetest(
    last: Candle,
    level: number,
    direction: 'up' | 'down'
  ): {
    nearLevel: boolean;
    distanceFromLevel: number;
    touches: number;
  } {
    const currentPrice = last.close;
    const distanceFromLevel = Math.abs(currentPrice - level) / level;
    const nearLevel = distanceFromLevel < this.NEAR_THRESHOLD;

    // Count touches near level in recent candles
    const touches = 1; // Simplified for now

    return { nearLevel, distanceFromLevel: distanceFromLevel * 100, touches };
  }

  private static isRetestSuccessful(
    last: Candle,
    level: number,
    direction: 'up' | 'down'
  ): boolean {
    const currentPrice = last.close;

    if (direction === 'up') {
      // Successful if level now acts as support (low touched, close above)
      return last.low <= level * 1.002 && currentPrice > level;
    } else {
      // Successful if level now acts as resistance (high touched, close below)
      return last.high >= level * 0.998 && currentPrice < level;
    }
  }

  private static calculateScore(
    retestState: { nearLevel: boolean },
    successful: boolean,
    direction: 'up' | 'down'
  ): number {
    let score = 0;

    if (retestState.nearLevel) {
      if (successful) {
        score = direction === 'up' ? 25 : -25;
      } else {
        score = 5; // Near level, checking
      }
    }

    return Math.max(-100, Math.min(100, Math.round(score)));
  }

  private static insufficientData(): EngineResult {
    return {
      score: 0,
      pass: false,
      reasons: ['Insufficient data for retest analysis'],
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  close: number;
}
