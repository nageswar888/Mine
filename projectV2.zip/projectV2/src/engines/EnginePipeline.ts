// Engine Pipeline - Coordinates execution of all engines
// No engine directly modifies another engine
// Only the Pipeline coordinates execution

import { MarketSnapshot, DecisionOutput, EngineResult, Timeframe } from '../types';
import { DataEngine } from './DataEngine';
import { IndicatorEngine } from './indicators';

// Analysis Engines
import { TrendEngine } from './analysis/TrendEngine';
import { MomentumEngine } from './analysis/MomentumEngine';
import { StructureEngine } from './analysis/StructureEngine';
import { VolatilityEngine } from './analysis/VolatilityEngine';
import { RegimeEngine } from './analysis/RegimeEngine';
import { SupportResistanceEngine } from './analysis/SupportResistanceEngine';
import { CandlestickEngine } from './analysis/CandlestickEngine';
import { LiquidityEngine } from './analysis/LiquidityEngine';
import { SessionEngine } from './analysis/SessionEngine';
import { TrendAgeEngine } from './analysis/TrendAgeEngine';
import { TrendSlopeEngine } from './analysis/TrendSlopeEngine';
import { StabilityEngine } from './analysis/StabilityEngine';
import { PullbackEngine } from './analysis/PullbackEngine';
import { BreakoutEngine } from './analysis/BreakoutEngine';
import { RetestEngine } from './analysis/RetestEngine';
import { OpportunityEngine } from './analysis/OpportunityEngine';
import { MarketContextEngine } from './analysis/MarketContextEngine';
import { EntryEngine } from './analysis/EntryEngine';
import { AdaptiveSuggestionEngine } from './analysis/AdaptiveSuggestionEngine';

// Historical Engines
import { HistoricalMemoryEngine } from './history/HistoricalMemoryEngine';
import { HistoricalProbabilityEngine } from './history/HistoricalProbabilityEngine';
import { ReplayEngine } from './history/ReplayEngine';

// Intelligence Engines
import { RiskEngine } from './intelligence/RiskEngine';
import { ConfluenceEngine } from './intelligence/ConfluenceEngine';
import { ValidatorEngine } from './intelligence/ValidatorEngine';
import { EliteEngine } from './intelligence/EliteEngine';
import { DecisionEngine } from './intelligence/DecisionEngine';

// History
import { TradeJournal } from './history/TradeJournal';

export interface PipelineResult {
  decision: DecisionOutput;
  analysisResults: Record<string, EngineResult>;
  indicators: ReturnType<typeof IndicatorEngine.calculateAll>;
  journalEntry: ReturnType<TradeJournal['record']>;
  executionTimeMs: number;
  lastCandleTimestamp: number;
}

export class EnginePipeline {
  private dataEngine: DataEngine;
  private tradeJournal: TradeJournal;
  private historicalMemory: HistoricalMemoryEngine;

  constructor(apiKey?: string, demoMode: boolean = false) {
    this.dataEngine = new DataEngine({ apiKey, demoMode });
    this.tradeJournal = new TradeJournal();
    this.historicalMemory = new HistoricalMemoryEngine();
  }

  setApiKey(key: string): void {
    this.dataEngine.setApiKey(key);
  }

  enableDemoMode(): void {
    this.dataEngine.enableDemoMode();
  }

  isDemoMode(): boolean {
    return this.dataEngine.isDemoMode();
  }

  getDataEngine(): DataEngine {
    return this.dataEngine;
  }

  getTradeJournal(): TradeJournal {
    return this.tradeJournal;
  }

  async execute(pair: string, timeframe: Timeframe): Promise<PipelineResult> {
    // DATA LAYER - Fetch and validate market data
    const candles = await this.dataEngine.fetchCandles(pair, timeframe, 60);
    const snapshot: MarketSnapshot = this.dataEngine.createSnapshot(pair, timeframe, candles);

    const startTime = performance.now();

    // INDICATOR LAYER - Calculate all indicators
    const indicators = IndicatorEngine.calculateAll(candles);

    // ANALYSIS LAYER - Run all analysis engines
    const analysisResults = this.runAnalysisEngines(snapshot);

    // INTELLIGENCE LAYER - Risk, Confluence, Validation
    const risk = RiskEngine.analyze(snapshot);
    const confluence = ConfluenceEngine.analyze(snapshot, analysisResults);
    const validation = ValidatorEngine.validate(snapshot, analysisResults, risk, confluence);

    // Market Context and Entry before probability and elite
    const marketContext = MarketContextEngine.analyze(snapshot, analysisResults);
    analysisResults.marketContext = marketContext;

    const entry = EntryEngine.analyze(snapshot, analysisResults);
    analysisResults.entry = entry;

    const historicalProbability = HistoricalProbabilityEngine.analyze(analysisResults, this.historicalMemory);
    analysisResults.historicalProbability = historicalProbability;

    const elite = EliteEngine.analyze(snapshot, analysisResults, risk, confluence, validation, marketContext, entry, historicalProbability);
    analysisResults.elite = elite;

    const decision = DecisionEngine.decide(snapshot, analysisResults, risk, confluence, validation);

    const journalEntry = this.tradeJournal.record(
      decision.decision,
      decision,
      pair,
      timeframe,
      candles[candles.length - 1]?.close || 0,
      analysisResults
    );

    this.historicalMemory.addTrade(journalEntry);

    const endTime = performance.now();
    const executionTimeMs = Math.round(endTime - startTime);

    return {
      decision,
      analysisResults,
      indicators,
      journalEntry,
      executionTimeMs,
      lastCandleTimestamp: snapshot.latestCandleTimestamp
    };
  }

  async executeSnapshot(snapshot: MarketSnapshot, recordHistory: boolean = false): Promise<PipelineResult> {
    const startTime = performance.now();

    const indicators = IndicatorEngine.calculateAll(snapshot.candles);
    const analysisResults = this.runAnalysisEngines(snapshot);
    const risk = RiskEngine.analyze(snapshot);
    const confluence = ConfluenceEngine.analyze(snapshot, analysisResults);
    const validation = ValidatorEngine.validate(snapshot, analysisResults, risk, confluence);

    const marketContext = MarketContextEngine.analyze(snapshot, analysisResults);
    analysisResults.marketContext = marketContext;

    const entry = EntryEngine.analyze(snapshot, analysisResults);
    analysisResults.entry = entry;

    const historicalProbability = HistoricalProbabilityEngine.analyze(analysisResults, this.historicalMemory);
    analysisResults.historicalProbability = historicalProbability;

    const adaptiveSuggestions = AdaptiveSuggestionEngine.analyze(analysisResults);
    analysisResults.adaptiveSuggestion = adaptiveSuggestions;

    const elite = EliteEngine.analyze(snapshot, analysisResults, risk, confluence, validation, marketContext, entry, historicalProbability);
    analysisResults.elite = elite;

    const decision = DecisionEngine.decide(snapshot, analysisResults, risk, confluence, validation);

    const journalEntry = recordHistory
      ? this.tradeJournal.record(
          decision.decision,
          decision,
          snapshot.pair,
          snapshot.timeframe,
          snapshot.currentPrice,
          analysisResults
        )
      : {
          id: `${snapshot.timestamp}-${Math.random().toString(36).substr(2, 9)}`,
          pair: snapshot.pair,
          timeframe: snapshot.timeframe,
          decision: decision.decision,
          tradeScore: decision.tradeScore,
          confidence: decision.confidence,
          price: snapshot.currentPrice,
          reasons: decision.reasons,
          timestamp: snapshot.timestamp,
          engineResults: analysisResults
        };

    if (recordHistory) {
      this.historicalMemory.addTrade(journalEntry);
    }

    const endTime = performance.now();
    const executionTimeMs = Math.round(endTime - startTime);

    return {
      decision,
      analysisResults,
      indicators,
      journalEntry,
      executionTimeMs,
      lastCandleTimestamp: snapshot.latestCandleTimestamp
    };
  }

  async replay(pair: string, timeframe: Timeframe, candles: any[]): Promise<PipelineResult[]> {
    return ReplayEngine.replay(this, pair, timeframe, candles);
  }

  private runAnalysisEngines(snapshot: MarketSnapshot): Record<string, EngineResult> {
    const results: Record<string, EngineResult> = {};

    // Run all analysis engines in sequence
    results.trend = TrendEngine.analyze(snapshot);
    results.momentum = MomentumEngine.analyze(snapshot);
    results.structure = StructureEngine.analyze(snapshot);
    results.volatility = VolatilityEngine.analyze(snapshot);
    results.regime = RegimeEngine.analyze(snapshot);
    results.supportResistance = SupportResistanceEngine.analyze(snapshot);
    results.candlestick = CandlestickEngine.analyze(snapshot);
    results.liquidity = LiquidityEngine.analyze(snapshot);
    results.session = SessionEngine.analyze(snapshot);
    results.trendAge = TrendAgeEngine.analyze(snapshot);
    results.trendSlope = TrendSlopeEngine.analyze(snapshot);
    results.stability = StabilityEngine.analyze(snapshot);
    results.pullback = PullbackEngine.analyze(snapshot);
    results.breakout = BreakoutEngine.analyze(snapshot);
    results.retest = RetestEngine.analyze(snapshot);

    // Opportunity engine needs other results
    results.opportunity = OpportunityEngine.analyze(snapshot, results);

    return results;
  }

  static getAvailablePairs(): { forex: string[]; crypto: string[] } {
    return DataEngine.getAvailablePairs();
  }
}
