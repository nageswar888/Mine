// Risk Engine - Evaluates market, trend, volatility, entry, liquidity risk
// NEVER generates CALL/PUT signals

import { MarketSnapshot, RiskAssessment, EngineResult } from '../../types';
import { IndicatorEngine } from '../indicators';

export class RiskEngine {
  static analyze(snapshot: MarketSnapshot): RiskAssessment {
    const { candles } = snapshot;

    if (candles.length < 30) {
      return this.insufficientData();
    }

    const closes = candles.map(c => c.close);
    const atr = IndicatorEngine.atr(candles, 14);
    const adx = IndicatorEngine.adx(candles);

    // Calculate individual risks
    const marketRisk = this.calculateMarketRisk(candles);
    const trendRisk = this.calculateTrendRisk(adx, candles);
    const volatilityRisk = this.calculateVolatilityRisk(atr, closes);
    const liquidityRisk = this.calculateLiquidityRisk(candles);
    const entryRisk = this.calculateEntryRisk(candles, atr);

    // Calculate total risk
    const totalRisk = this.calculateTotalRisk({
      marketRisk,
      trendRisk,
      volatilityRisk,
      liquidityRisk,
      entryRisk
    });

    // Determine recommendation
    const recommendation = this.getRecommendation(totalRisk);

    // Calculate score
    const score = this.calculateScore(totalRisk, recommendation);

    const pass = totalRisk <= 60;

    const reasons: string[] = [];
    if (recommendation === 'low') {
      reasons.push('Low overall risk - favorable conditions');
    } else if (recommendation === 'moderate') {
      reasons.push('Moderate risk - proceed with caution');
    } else if (recommendation === 'high') {
      reasons.push('High risk - consider smaller position');
    } else {
      reasons.push('Extreme risk - avoid trading');
    }

    if (volatilityRisk > 70) reasons.push('⚠ High volatility risk');
    if (trendRisk > 70) reasons.push('⚠ Unclear trend direction');
    if (liquidityRisk > 60) reasons.push('⚠ Low liquidity conditions');

    return {
      score,
      pass,
      reasons,
      marketRisk,
      trendRisk,
      volatilityRisk,
      liquidityRisk,
      entryRisk,
      totalRisk,
      recommendation,
      details: {
        atr: atr[candles.length - 1] || 0,
        adx: adx[candles.length - 1] || 25,
        pricePosition: this.getPricePosition(candles)
      }
    };
  }

  private static calculateMarketRisk(candles: Candle[]): number {
    // Market risk based on recent price movement
    const recent = candles.slice(-20);
    const closes = recent.map(c => c.close);
    const highs = recent.map(c => c.high);
    const lows = recent.map(c => c.low);

    // Calculate average range
    const avgRange = highs.reduce((s, h, i) => s + (h - lows[i]), 0) / highs.length;
    const avgPrice = closes.reduce((s, c) => s + c, 0) / closes.length;
    const rangePercent = (avgRange / avgPrice) * 100;

    // Higher range = higher market risk
    return Math.min(100, rangePercent * 20);
  }

  private static calculateTrendRisk(adx: number[], candles: Candle[]): number {
    const lastAdx = adx[candles.length - 1] || 25;

    // Low ADX = choppy = higher trend risk
    if (lastAdx < 20) return 80;
    if (lastAdx < 25) return 60;
    if (lastAdx < 30) return 40;
    return 20;
  }

  private static calculateVolatilityRisk(atr: number[], closes: number[]): number {
    const lastIdx = closes.length - 1;
    const lastAtr = atr[lastIdx] || 0;
    const price = closes[lastIdx];

    // ATR as percentage of price
    const atrPercent = (lastAtr / price) * 100;

    // Categorize volatility risk
    if (atrPercent > 2) return 90; // Extreme volatility
    if (atrPercent > 1) return 70;
    if (atrPercent > 0.5) return 50;
    if (atrPercent < 0.1) return 40; // Too low volatility
    return 30;
  }

  private static calculateLiquidityRisk(candles: Candle[]): number {
    const volumes = candles.slice(-10).map(c => c.volume);
    const avgVolume = volumes.reduce((s, v) => s + v, 0) / volumes.length;
    const lastVolume = volumes[volumes.length - 1];

    // Low volume = high liquidity risk
    if (lastVolume < avgVolume * 0.5) return 70;
    if (lastVolume < avgVolume * 0.7) return 50;
    if (lastVolume > avgVolume * 1.5) return 40; // High volume is okay
    return 30;
  }

  private static calculateEntryRisk(candles: Candle[], atr: number[]): number {
    const last = candles[candles.length - 1];
    const prev = candles[candles.length - 2];
    const lastAtr = atr[candles.length - 1] || 0;

    // Risk if entering at extreme of candle
    const mid = (last.high + last.low) / 2;
    const distanceFromMid = Math.abs(last.close - mid) / (last.high - last.low || 1);

    // Entering at extreme = higher risk
    const extremeRisk = distanceFromMid * 50;

    // ATR expansion risk
    const prevAtr = atr[candles.length - 2] || lastAtr;
    const atrExpansion = lastAtr > prevAtr * 1.3 ? 20 : 0;

    return Math.min(100, extremeRisk + atrExpansion);
  }

  private static calculateTotalRisk(risks: {
    marketRisk: number;
    trendRisk: number;
    volatilityRisk: number;
    liquidityRisk: number;
    entryRisk: number;
  }): number {
    // Weighted average
    return Math.round(
      risks.marketRisk * 0.2 +
      risks.trendRisk * 0.25 +
      risks.volatilityRisk * 0.25 +
      risks.liquidityRisk * 0.15 +
      risks.entryRisk * 0.15
    );
  }

  private static getRecommendation(totalRisk: number): 'low' | 'moderate' | 'high' | 'extreme' {
    if (totalRisk <= 35) return 'low';
    if (totalRisk <= 50) return 'moderate';
    if (totalRisk <= 70) return 'high';
    return 'extreme';
  }

  private static calculateScore(
    totalRisk: number,
    recommendation: string
  ): number {
    let score = 0;

    // Lower risk = higher score
    score = 100 - totalRisk;

    // Risk always has higher priority - reduce score if high risk
    if (recommendation === 'high') score *= 0.6;
    if (recommendation === 'extreme') score *= 0.3;

    return Math.max(-100, Math.min(100, Math.round(score - 50)));
  }

  private static getPricePosition(candles: Candle[]): string {
    const recent = candles.slice(-20);
    const recentHigh = Math.max(...recent.map(c => c.high));
    const recentLow = Math.min(...recent.map(c => c.low));
    const current = candles[candles.length - 1].close;

    const range = recentHigh - recentLow;
    const position = range > 0 ? (current - recentLow) / range : 0.5;

    if (position > 0.9) return 'near_high';
    if (position < 0.1) return 'near_low';
    return 'mid_range';
  }

  private static insufficientData(): RiskAssessment {
    return {
      score: -100,
      pass: false,
      reasons: ['Insufficient data for risk analysis'],
      marketRisk: 100,
      trendRisk: 100,
      volatilityRisk: 100,
      liquidityRisk: 100,
      entryRisk: 100,
      totalRisk: 100,
      recommendation: 'extreme',
      details: {}
    };
  }
}

interface Candle {
  high: number;
  low: number;
  close: number;
  volume: number;
}
