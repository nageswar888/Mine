// Session Engine - Evaluates current trading session
// NEVER generates CALL/PUT signals
// ACCURACY FOCUS: Only trade during high-liquidity sessions

import { MarketSnapshot, SessionAnalysis, Session } from '../../types';

export class SessionEngine {
  // Session times in UTC (when real liquidity exists)
  private static readonly SESSIONS = {
    london: { start: 8, end: 16, weight: 1.0 },
    new_york: { start: 13, end: 21, weight: 0.95 },
    overlap: { start: 13, end: 16, weight: 1.0 },  // London/NY overlap = best
    asia: { start: 23, end: 7, weight: 0.6 },      // Lower for non-forex pairs
    sydney: { start: 22, end: 5, weight: 0.4 }
  };

  // Avoid these hours (low liquidity = low accuracy)
  private static readonly AVOID_HOURS = [17, 18, 19, 20, 21, 22]; // Between NY close and Asia open

  static analyze(snapshot: MarketSnapshot): SessionAnalysis {
    const { candles, pair } = snapshot;

    if (candles.length < 5) {
      return this.insufficientData();
    }

    const lastCandle = candles[candles.length - 1];
    const timestamp = lastCandle.timestamp || Date.now();
    const currentSession = this.getCurrentSession(timestamp);

    // Determine if optimal trading time
    const { active, isOptimal } = this.isOptimalSession(currentSession, timestamp, pair);

    // Calculate liquidity score
    const liquidity = this.calculateLiquidity(currentSession, pair, timestamp);

    // Calculate score with accuracy emphasis
    const score = this.calculateScore(currentSession, isOptimal, liquidity);

    // STRICT PASS: must be in optimal session with sufficient liquidity
    const pass = isOptimal && liquidity >= 70;

    const reasons: string[] = [];
    if (currentSession === 'overlap') {
      reasons.push('London/NY overlap - highest accuracy window');
    } else if (currentSession === 'london') {
      reasons.push('London session - high liquidity');
    } else if (currentSession === 'new_york') {
      reasons.push('New York session - active trading');
    } else if (currentSession === 'asia') {
      reasons.push('Asia session - moderate conditions');
    } else {
      reasons.push('⚠ Low liquidity period - reduced accuracy');
    }

    if (!isOptimal) {
      const hour = new Date(timestamp).getUTCHours();
      if (this.AVOID_HOURS.includes(hour)) {
        reasons.push('⚠ Market downtime - avoid trading');
      }
    }

    if (liquidity >= 80) {
      reasons.push('High liquidity - spreads tight');
    } else if (liquidity < 50) {
      reasons.push('⚠ Low liquidity - wider spreads expected');
    }

    return {
      score,
      pass,
      reasons,
      current: currentSession,
      active,
      liquidity,
      details: {
        hour: new Date(timestamp).getUTCHours(),
        isOptimal,
        suggestedPairs: this.getSuggestedPairs(currentSession),
        optimalIn: this.timeToOptimalSession(timestamp)
      }
    };
  }

  private static getCurrentSession(timestamp: number): Session {
    const hour = new Date(timestamp).getUTCHours();

    // Check overlap first (highest priority)
    if (hour >= this.SESSIONS.overlap.start && hour < this.SESSIONS.overlap.end) {
      return 'overlap';
    }

    // London
    if (hour >= this.SESSIONS.london.start && hour < this.SESSIONS.london.end) {
      return 'london';
    }

    // New York
    if (hour >= this.SESSIONS.new_york.start && hour < this.SESSIONS.new_york.end) {
      return 'new_york';
    }

    // Asia (crosses midnight UTC)
    if (hour >= 23 || hour < 7) {
      return 'asia';
    }

    return 'off';
  }

  private static isOptimalSession(
    session: Session,
    timestamp: number,
    pair: string
  ): { active: boolean; isOptimal: boolean } {
    const hour = new Date(timestamp).getUTCHours();
    const isForex = this.isForexPair(pair);

    // Never trade during avoid hours
    if (this.AVOID_HOURS.includes(hour)) {
      return { active: false, isOptimal: false };
    }

    // Crypto trades 24/7 with varying liquidity
    if (!isForex) {
      return {
        active: session !== 'off',
        isOptimal: session === 'overlap' || session === 'london' || session === 'new_york'
      };
    }

    // Forex: optimal during major sessions
    const active = session === 'overlap' || session === 'london' || session === 'new_york';
    const isOptimal = session === 'overlap' ||
                      (session === 'london' && hour >= 9 && hour < 16) ||
                      (session === 'new_york' && hour >= 14 && hour < 20);

    return { active, isOptimal };
  }

  private static isForexPair(pair: string): boolean {
    return pair.includes('USD') || pair.includes('EUR') || pair.includes('GBP') ||
           pair.includes('JPY') || pair.includes('AUD') || pair.includes('CAD') ||
           pair.includes('CHF') || pair.includes('NZD');
  }

  private static calculateLiquidity(session: Session, pair: string, timestamp: number): number {
    const hour = new Date(timestamp).getUTCHours();

    // Base liquidity by session
    const sessionLiquidity: Record<Session, number> = {
      overlap: 98,      // Maximum liquidity
      london: 88,
      new_york: 82,
      asia: 55,
      off: 25
    };

    let liquidity = sessionLiquidity[session];

    // Adjust for pair relevance to session
    if (this.isForexPair(pair)) {
      if (session === 'london' && (pair.includes('EUR') || pair.includes('GBP'))) {
        liquidity += 5;
      }
      if (session === 'new_york' && pair.includes('USD')) {
        liquidity += 5;
      }
      if (session === 'asia' && (pair.includes('JPY') || pair.includes('AUD'))) {
        liquidity += 8;
      }
    }

    // Penalty for avoid hours
    if (this.AVOID_HOURS.includes(hour)) {
      liquidity = Math.max(20, liquidity - 40);
    }

    return Math.min(100, liquidity);
  }

  private static calculateScore(session: Session, isOptimal: boolean, liquidity: number): number {
    if (!isOptimal) return -25;

    let score = 0;

    // Session contribution
    if (session === 'overlap') score = 35;
    else if (session === 'london') score = 28;
    else if (session === 'new_york') score = 22;
    else if (session === 'asia') score = 8;
    else score = -20;

    // Liquidity modifier
    if (liquidity >= 85) score += 15;
    else if (liquidity < 60) score -= 15;

    return Math.max(-100, Math.min(100, score));
  }

  private static getSuggestedPairs(session: Session): string[] {
    switch (session) {
      case 'london':
        return ['EUR/USD', 'GBP/USD', 'EUR/GBP', 'GBP/JPY'];
      case 'new_york':
        return ['EUR/USD', 'USD/JPY', 'GBP/USD', 'USD/CAD'];
      case 'overlap':
        return ['EUR/USD', 'GBP/USD', 'GBP/JPY', 'EUR/JPY'];
      case 'asia':
        return ['USD/JPY', 'AUD/USD', 'EUR/JPY', 'AUD/JPY'];
      default:
        return ['BTC/USD', 'ETH/USD', 'XRP/USD'];
    }
  }

  private static timeToOptimalSession(timestamp: number): string {
    const hour = new Date(timestamp).getUTCHours();

    // Find next optimal session
    if (hour < 8) return `${8 - hour}h to London open`;
    if (hour >= 8 && hour < 13) return `${13 - hour}h to NY open (overlap)`;
    if (hour >= 16 && hour < 23) return `${23 - hour}h to Asia open`;
    return 'Optimal session active';
  }

  private static insufficientData(): SessionAnalysis {
    return {
      score: -50,
      pass: false,
      reasons: ['Insufficient data for session analysis'],
      current: 'off',
      active: false,
      liquidity: 0,
      details: { hour: 0, isOptimal: false, suggestedPairs: [], optimalIn: 'Unknown' }
    };
  }
}
