import { EnginePipeline } from '../EnginePipeline';
import { Candle, MarketSnapshot, Timeframe } from '../../types';

export class BacktestEngine {
  static async backtest(
    pipeline: EnginePipeline,
    pair: string,
    timeframe: Timeframe,
    candles: Candle[]
  ): Promise<{
    winRate: number;
    lossRate: number;
    tradeCount: number;
    avgTradeScore: number;
    avgConfidence: number;
  }> {
    const results = await pipeline.replay(pair, timeframe, candles);
    const trades = results.map(r => r.decision).filter(d => d.decision !== 'WAIT');

    const tradeCount = trades.length;
    const avgTradeScore = tradeCount > 0 ? Math.round(trades.reduce((sum, t) => sum + t.tradeScore, 0) / tradeCount) : 0;
    const avgConfidence = tradeCount > 0 ? Math.round(trades.reduce((sum, t) => sum + t.confidence, 0) / tradeCount) : 0;
    const winRate = Math.round(trades.filter(t => t.confidence >= 70).length / Math.max(tradeCount, 1) * 100);
    const lossRate = 100 - winRate;

    return { winRate, lossRate, tradeCount, avgTradeScore, avgConfidence };
  }
}
