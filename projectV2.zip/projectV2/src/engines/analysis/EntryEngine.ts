import { MarketSnapshot, EntryAnalysis, ExpiryRecommendation, BreakoutAnalysis, SupportResistanceAnalysis, MarketContextAnalysis, LiquidityAnalysis, StructureAnalysis, EngineResult } from '../../types';

export class EntryEngine {
  static analyze(
    snapshot: MarketSnapshot,
    engineResults: Record<string, EngineResult>
  ): EntryAnalysis {
    const { candles, currentPrice } = snapshot;
    const breakout = engineResults['breakout'] as BreakoutAnalysis | undefined;
    const supportResistance = engineResults['supportResistance'] as SupportResistanceAnalysis | undefined;
    const structure = engineResults['structure'] as StructureAnalysis | undefined;
    const liquidity = engineResults['liquidity'] as LiquidityAnalysis | undefined;
    const marketContext = engineResults['marketContext'] as MarketContextAnalysis | undefined;

    const entryPrice = currentPrice;
    let entryDelay = 0;
    let entryWindow = 3;
    let valid = false;
    let expiryRecommendation: ExpiryRecommendation = 'none';

    if (breakout?.details?.breakoutLevel && breakout.pass) {
      const level = breakout.details.breakoutLevel as number;
      const distance = Math.abs(currentPrice - level) / level * 100;
      entryDelay = distance > 0.3 ? 1 : 0;
      valid = breakout.details?.retest === true && breakout.pass;
      entryWindow = valid ? 4 : 2;
    }

    if (supportResistance && supportResistance.nearestSupport !== undefined && supportResistance.nearestResistance !== undefined) {
      const range = supportResistance.nearestResistance - supportResistance.nearestSupport;
      if (range > 0) {
        const position = (currentPrice - supportResistance.nearestSupport) / range;
        if (position > 0.2 && position < 0.8) {
          entryWindow = Math.max(entryWindow, 4);
          valid = valid || true;
        }
      }
    }

    if (marketContext?.details) {
      const state = (marketContext.details as any).state;
      if (marketContext && marketContext.score > 50) {
        expiryRecommendation = 'short';
      } else if (marketContext && marketContext.score > 30) {
        expiryRecommendation = 'medium';
      } else {
        expiryRecommendation = 'long';
      }
    }

    if (liquidity?.details?.fakeoutDetected) {
      valid = false;
    }

    if (structure?.details?.pattern === 'none') {
      valid = false;
    }

    if (breakout?.confirmed === true && breakout.retest === true && valid) {
      expiryRecommendation = 'short';
    }

    const reasons: string[] = [];
    if (valid) {
      reasons.push('Entry is aligned with breakout and support/resistance');
    } else {
      reasons.push('Entry conditions are not fully satisfied');
    }

    if (entryDelay > 0) {
      reasons.push(`Entry delay recommended: ${entryDelay} candle(s)`);
    }

    return {
      score: valid ? 40 : -20,
      pass: valid,
      reasons,
      entryPrice,
      entryDelay,
      entryWindow,
      valid,
      expiryRecommendation,
      details: {
        structurePattern: structure?.details?.pattern || 'unknown',
        breakoutConfirmed: breakout?.confirmed || false,
        supportResistanceDistance: supportResistance?.distanceToNearest || 0
      }
    };
  }
}
