import React, { useState, useEffect, useCallback, useRef } from 'react';
import { EnginePipeline } from './engines/EnginePipeline';
import { Timeframe, Decision, SessionStats, TradeRecord, EngineResult } from './types';

interface SetupProps {
  onConnect: (apiKey: string) => void;
  onDemo: () => void;
}

const SetupOverlay: React.FC<SetupProps> = ({ onConnect, onDemo }) => {
  const [apiKey, setApiKey] = useState('');
  const [status, setStatus] = useState<{ type: string; msg: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConnect = async () => {
    if (!apiKey.trim()) {
      setStatus({ type: 'err', msg: 'Please enter your API key' });
      return;
    }
    setLoading(true);
    setStatus({ type: 'load', msg: 'Testing connection...' });

    try {
      const result = await fetch(`https://api.twelvedata.com/price?symbol=EUR/USD&apikey=${apiKey}`);
      const data = await result.json();

      if (data.code === 401) {
        setStatus({ type: 'err', msg: 'Invalid API key' });
      } else if (data.price) {
        setStatus({ type: 'ok', msg: 'Connected successfully!' });
        setTimeout(() => onConnect(apiKey), 500);
      } else {
        setStatus({ type: 'err', msg: data.message || 'Connection failed' });
      }
    } catch (e) {
      setStatus({ type: 'err', msg: 'Network error - try demo mode' });
    }
    setLoading(false);
  };

  return (
    <div className="setup-overlay">
      <div className="setup-card">
        <div className="setup-logo">SignalX</div>
        <div className="setup-tagline">Professional Decision Engine for Binary Options</div>

        <div className="setup-step">
          <div className="step-num">1</div>
          <div className="step-text">
            Go to <a href="https://twelvedata.com" target="_blank" rel="noreferrer">twelvedata.com</a> and get a free API key
          </div>
        </div>
        <div className="setup-step">
          <div className="step-num">2</div>
          <div className="step-text">
            Paste your API key below. Free plan includes 800 API calls/day
          </div>
        </div>
        <div className="setup-step">
          <div className="step-num">3</div>
          <div className="step-text">
            Engine will analyze 15+ market factors before producing CALL, PUT, or WAIT
          </div>
        </div>

        <div className="setup-divider" />

        <div className="setup-input-label">Your Twelve Data API Key</div>
        <div className="setup-input-row">
          <input
            className="setup-input"
            type="text"
            placeholder="e.g. a1b2c3d4e5f6789..."
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleConnect()}
          />
          <button className="setup-btn" onClick={handleConnect} disabled={loading}>
            Connect
          </button>
        </div>

        {status && (
          <div className={`setup-status status-${status.type}`}>{status.msg}</div>
        )}

        <button className="demo-btn" onClick={onDemo}>
          Continue in Demo Mode (simulated data)
        </button>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [showSetup, setShowSetup] = useState(true);
  const [pipeline] = useState(() => new EnginePipeline(undefined, true));
  const [activePair, setActivePair] = useState('EUR/USD');
  const [timeframe, setTimeframe] = useState<Timeframe>('15min');
  const [loading, setLoading] = useState(false);
  const [clock, setClock] = useState('');
  const [timeframeCountdown, setTimeframeCountdown] = useState(900);
  const [refreshIntervalSeconds] = useState(() => pipeline.getDataEngine().getRefreshIntervalSeconds());
  const [refreshCountdown, setRefreshCountdown] = useState(() => pipeline.getDataEngine().getRefreshIntervalSeconds());
  const refreshDeadlineRef = useRef(Date.now() + pipeline.getDataEngine().getRefreshIntervalSeconds() * 1000);
  const [decision, setDecision] = useState<{
    decision: Decision;
    tradeScore: number;
    confidence: number;
    reasons: string[];
    timestamp: number;
  } | null>(null);
  const [engineResults, setEngineResults] = useState<Record<string, EngineResult>>({});
  const [stats, setStats] = useState<SessionStats>({ total: 0, calls: 0, puts: 0, waits: 0, avgConfidence: 0, avgTradeScore: 0 });
  const [tradeLog, setTradeLog] = useState<TradeRecord[]>([]);
  const [prices, setPrices] = useState<Record<string, number>>({});
  const [toast, setToast] = useState<{ show: boolean; decision: Decision; pair: string; confidence: number } | null>(null);

  const getTimeframeSeconds = (tf: Timeframe) => (tf === '5min' ? 300 : 900);

  // Play sound for signals
  const playSignalSound = useCallback((decision: Decision) => {
    if (decision === 'WAIT') return;
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = decision === 'CALL' ? 880 : 440;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (e) {
      console.log('Audio not supported');
    }
  }, []);

  const pairs = EnginePipeline.getAvailablePairs();

  useEffect(() => {
    const timer = setInterval(() => {
      setClock(new Date().toLocaleTimeString('en-US', { hour12: false }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setTimeframeCountdown(getTimeframeSeconds(timeframe));
  }, [timeframe]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeframeCountdown((current) => {
        if (current <= 1) {
          return getTimeframeSeconds(timeframe);
        }
        return current - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [timeframe]);

  const runAnalysis = useCallback(async () => {
    setLoading(true);
    try {
      const result = await pipeline.execute(activePair, timeframe);
      setDecision(result.decision);
      setEngineResults(result.analysisResults);

      refreshDeadlineRef.current = Date.now() + refreshIntervalSeconds * 1000;
      setRefreshCountdown(refreshIntervalSeconds);

      const journal = pipeline.getTradeJournal();
      setStats(journal.getSessionStats());
      setTradeLog(journal.getRecent(15));

      const dataEngine = pipeline.getDataEngine();
      const demoPrices = dataEngine.getDemoPrices();
      setPrices(demoPrices);

      if (result.decision.decision !== 'WAIT') {
        playSignalSound(result.decision.decision);
        setToast({
          show: true,
          decision: result.decision.decision,
          pair: activePair,
          confidence: result.decision.confidence
        });
        setTimeout(() => setToast(null), 5000);
      }
    } catch (e) {
      console.error('Analysis error:', e);
    }
    setLoading(false);
  }, [activePair, timeframe, pipeline, playSignalSound]);

  useEffect(() => {
    if (showSetup) {
      return undefined;
    }

    const timer = window.setInterval(() => {
      const remaining = Math.max(0, Math.ceil((refreshDeadlineRef.current - Date.now()) / 1000));
      setRefreshCountdown(remaining);

      if (remaining <= 0 && !loading) {
        refreshDeadlineRef.current = Date.now() + refreshIntervalSeconds * 1000;
        setRefreshCountdown(refreshIntervalSeconds);
        void runAnalysis();
      }
    }, 1000);

    return () => window.clearInterval(timer);
  }, [showSetup, loading, refreshIntervalSeconds, runAnalysis]);

  useEffect(() => {
    if (!showSetup) {
      runAnalysis();
    }
  }, [showSetup, activePair, timeframe, runAnalysis]);

  const handleConnect = (apiKey: string) => {
    pipeline.setApiKey(apiKey);
    setShowSetup(false);
  };

  const handleDemo = () => {
    pipeline.enableDemoMode();
    setShowSetup(false);
  };

  const selectPair = (pair: string) => {
    setActivePair(pair);
  };

  const selectTimeframe = (tf: Timeframe) => {
    setTimeframe(tf);
    setTimeframeCountdown(getTimeframeSeconds(tf));
  };

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const timeframeSeconds = getTimeframeSeconds(timeframe);
  const currentTimeframeCountdown = timeframeCountdown;
  const currentRefreshCountdown = refreshCountdown;

  const getSeedPrice = (pair: string) => {
    const seeds: Record<string, number> = {
      'EUR/USD': 1.0842, 'GBP/USD': 1.2731, 'USD/JPY': 149.82, 'AUD/USD': 0.6521,
      'USD/CAD': 1.3614, 'EUR/GBP': 0.8521, 'BTC/USD': 67430, 'ETH/USD': 3512,
      'BNB/USD': 594, 'XRP/USD': 0.5831, 'SOL/USD': 172.4
    };
    return seeds[pair] || 1;
  };

  const isCrypto = (pair: string) => pair.includes('BTC') || pair.includes('ETH') || pair.includes('BNB') || pair.includes('XRP') || pair.includes('SOL');
  const decimals = (pair: string) => isCrypto(pair) ? 2 : 5;

  if (showSetup) {
    return <SetupOverlay onConnect={handleConnect} onDemo={handleDemo} />;
  }

  return (
    <div className="app-container">
      <div className="topbar">
        <div className="logo">SignalX Decision Engine</div>
        <div className={pipeline.isDemoMode() ? 'live-pill demo' : 'live-pill live'}>
          <div className="live-dot" />
          <span>{pipeline.isDemoMode() ? 'DEMO' : 'LIVE'}</span>
        </div>
        <div className="clock-display">{clock}</div>
      </div>

      <div className="app-body">
        <div className="sidebar">
          <div className="sidebar-scroll">
            <div>
              <div className="sec-label">Timeframe</div>
              <div className="tf-group">
                <button
                  className={`tf-btn ${timeframe === '5min' ? 'active' : ''}`}
                  onClick={() => selectTimeframe('5min')}
                >
                  5M
                </button>
                <button
                  className={`tf-btn ${timeframe === '15min' ? 'active' : ''}`}
                  onClick={() => selectTimeframe('15min')}
                >
                  15M
                </button>
              </div>
            </div>

            <div className="divider" />

            <div>
              <div className="sec-label">Forex Pairs</div>
              <div className="asset-list">
                {pairs.forex.map((pair) => {
                  const price = prices[pair] || getSeedPrice(pair);
                  const delta = (price - getSeedPrice(pair)) / getSeedPrice(pair) * 100;
                  return (
                    <div
                      key={pair}
                      className={`asset-row ${activePair === pair ? 'active' : ''}`}
                      onClick={() => selectPair(pair)}
                    >
                      <div className="a-left">
                        <div className="a-name">{pair}</div>
                        <div className="a-type">Forex</div>
                      </div>
                      <div className="a-right">
                        <div className="a-price">{price.toFixed(decimals(pair))}</div>
                        <div className={`a-change ${delta >= 0 ? 'up' : 'dn'}`}>
                          {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="divider" />

            <div>
              <div className="sec-label">Crypto</div>
              <div className="asset-list">
                {pairs.crypto.map((pair) => {
                  const price = prices[pair] || getSeedPrice(pair);
                  const delta = (price - getSeedPrice(pair)) / getSeedPrice(pair) * 100;
                  return (
                    <div
                      key={pair}
                      className={`asset-row ${activePair === pair ? 'active' : ''}`}
                      onClick={() => selectPair(pair)}
                    >
                      <div className="a-left">
                        <div className="a-name">{pair}</div>
                        <div className="a-type">Crypto</div>
                      </div>
                      <div className="a-right">
                        <div className="a-price">{price.toFixed(decimals(pair))}</div>
                        <div className={`a-change ${delta >= 0 ? 'up' : 'dn'}`}>
                          {delta >= 0 ? '▲' : '▼'} {Math.abs(delta).toFixed(2)}%
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="sidebar-bottom">
            <div className="next-signal">
              <div className="ns-label">Timeframe Ends In</div>
              <div className="ns-time">{formatCountdown(currentTimeframeCountdown)}</div>
              <div className="ns-bar-bg">
                <div
                  className="ns-bar-fill"
                  style={{ width: `${(currentTimeframeCountdown / timeframeSeconds) * 100}%` }}
                />
              </div>
            </div>
            <div className="next-signal">
              <div className="ns-label">Next Refresh In</div>
              <div className="ns-time">{formatCountdown(currentRefreshCountdown)}</div>
              <div className="ns-bar-bg">
                <div
                  className="ns-bar-fill"
                  style={{ width: `${(currentRefreshCountdown / refreshIntervalSeconds) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="center-panel">
          <div className="signal-bar">
            <div className="sb-left">
              <div className="sb-pair">{activePair}</div>
              <div className="sb-meta">
                <div className="sb-price">
                  {(prices[activePair] || getSeedPrice(activePair)).toFixed(decimals(activePair))}
                </div>
                <div className="sb-tf-tag">{timeframe === '5min' ? '5M' : '15M'}</div>
              </div>
            </div>
            <div className="sb-right">
              <div className="conf-block">
                <div className="conf-title">Confidence</div>
                <div className="ring-wrap">
                  <svg viewBox="0 0 68 68" width="68" height="68">
                    <circle className="ring-bg" cx="34" cy="34" r="28" />
                    <circle
                      className="ring-fg"
                      cx="34"
                      cy="34"
                      r="28"
                      strokeDasharray="175.9"
                      strokeDashoffset={175.9 - (175.9 * (decision?.confidence || 0)) / 100}
                      stroke={
                        decision?.decision === 'CALL' ? '#22c55e' :
                        decision?.decision === 'PUT' ? '#ef4444' : '#f59e0b'
                      }
                    />
                  </svg>
                  <div
                    className="ring-pct"
                    style={{
                      color: decision?.decision === 'CALL' ? '#22c55e' :
                             decision?.decision === 'PUT' ? '#ef4444' : '#f59e0b'
                    }}
                  >
                    {decision?.confidence || 0}%
                  </div>
                </div>
              </div>
              <div className="signal-block">
                <div className={`signal-chip ${decision?.decision || 'WAIT'}`}>
                  {decision?.decision || 'WAIT'}
                </div>
                <div className="signal-sub-label">Current Signal</div>
              </div>
            </div>
          </div>

          <div className="main-content">
            <div className="engines-panel">
              <div className="sec-label">Engine Analysis</div>
              <div className="engines-grid">
                {Object.entries(engineResults).map(([name, result]) => (
                  <div key={name} className="engine-card">
                    <div className="engine-header">
                      <div className="engine-name">{name.replace(/([A-Z])/g, ' $1').trim()}</div>
                      <div className={`engine-status ${result.pass ? 'pass' : 'fail'}`}>
                        {result.pass ? 'PASS' : 'FAIL'}
                      </div>
                    </div>
                    <div className={`engine-score ${
                      result.score > 15 ? 'positive' :
                      result.score < -15 ? 'negative' : 'neutral'
                    }`}>
                      {result.score > 0 ? '+' : ''}{result.score}
                    </div>
                    <div className="engine-reasons">
                      {result.reasons.slice(0, 2).join('. ')}
                    </div>
                  </div>
                ))}
              </div>

              {decision && decision.reasons.length > 0 && (
                <div className="reasons-panel">
                  <div className="reasons-title">Decision Reasons</div>
                  <div className="reasons-list">
                    {decision.reasons.map((reason, i) => (
                      <div key={i} className="reason-item">{reason}</div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="right-panel">
              <div className="rp-scroll">
                <div>
                  <div className="sec-label">Session Stats</div>
                  <div className="stats-grid">
                    <div className="stat-box">
                      <div className="stat-num" style={{ color: 'var(--text)' }}>{stats.total}</div>
                      <div className="stat-lbl">Total</div>
                    </div>
                    <div className="stat-box">
                      <div className="stat-num" style={{ color: 'var(--bull)' }}>{stats.calls}</div>
                      <div className="stat-lbl">CALL</div>
                    </div>
                    <div className="stat-box">
                      <div className="stat-num" style={{ color: 'var(--bear)' }}>{stats.puts}</div>
                      <div className="stat-lbl">PUT</div>
                    </div>
                    <div className="stat-box">
                      <div className="stat-num" style={{ color: 'var(--warn)' }}>{stats.waits}</div>
                      <div className="stat-lbl">WAIT</div>
                    </div>
                  </div>
                </div>

                <div className="divider" />

                <div>
                  <div className="sec-label">Signal Log</div>
                  <div className="log-list">
                    {tradeLog.length === 0 ? (
                      <div className="empty-log">No signals yet</div>
                    ) : (
                      tradeLog.map((trade) => (
                        <div key={trade.id} className="log-item">
                          <div className={`log-chip ${trade.decision}`}>{trade.decision}</div>
                          <div>
                            <div className="log-pair">{trade.pair}</div>
                            <div className="log-time">
                              {new Date(trade.timestamp).toLocaleTimeString('en-US', { hour12: false })}
                            </div>
                          </div>
                          <div
                            className="log-pct"
                            style={{
                              color: trade.decision === 'CALL' ? 'var(--bull)' :
                                     trade.decision === 'PUT' ? 'var(--bear)' : 'var(--warn)'
                            }}
                          >
                            {trade.confidence}%
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {loading && (
        <div className="loading-spinner">
          <div className="spinner" />
        </div>
      )}

      {toast && toast.show && (
        <div className={`toast show ${toast.decision}`}>
          {toast.decision === 'CALL' ? '🟢' : '🔴'} <strong>{toast.decision}</strong>
          &nbsp;{toast.pair} · {toast.confidence}% confidence
          &nbsp;· {toast.decision === 'CALL' ? '⬆ Click UP' : '⬇ Click DOWN'}
        </div>
      )}
    </div>
  );
};

export default App;
